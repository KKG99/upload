
% ============================================================
% NASA GROUP 2 VERIFICATION USING ORIGINAL GMCaniso.m
% NASA/TM-2002-212077/VOL3, Example 7e
%
% Units: GPa
% Physical axes:
% x1 = Thickness
% x2 = Warp
% x3 = Weft
%
% Four layers: Matrix - Inclined Tow - Inclined Tow - Matrix
% ============================================================

clear; clc;

addpath(fullfile(pwd,'WeaveProps'));
addpath(fullfile(pwd,'Functions','Utilities'));

% ============================================================
% 1. NASA TOW PROPERTIES
% ============================================================

TP.EL = 253.5;
TP.ET = 6.05;
TP.vL = 0.3901;
TP.vT = 0.4682;
TP.GL = 4.167;

Ctow = GetCFromProps(TP);

% ============================================================
% 2. NASA MATRIX PROPERTIES
% ============================================================

MP.EL = 3.45;
MP.ET = 3.45;
MP.vL = 0.35;
MP.vT = 0.35;
MP.GL = 3.45/(2*(1+0.35));

Cmat = GetCFromProps(MP);

atow = zeros(6,1);
amat = zeros(6,1);

% ============================================================
% 3. WARP AND INCLINED TOW STIFFNESS
% ============================================================

phi = atand(0.25);

[Cwarp,~] = TowCfull(Ctow,atow,0,0);
[Cweft,~] = TowCfull(Ctow,atow,90,0);
[Cinc,~]  = TowCfull(Ctow,atow,0,phi);

fprintf('\n========== TOW STIFFNESS ==========\n');

fprintf('Inclination = %.6f degrees\n',phi);

fprintf('Flat warp C22 = %.6f GPa\n',Cwarp(2,2));
fprintf('Flat weft C33 = %.6f GPa\n',Cweft(3,3));

fprintf('Inclined warp C22 = %.6f GPa\n',Cinc(2,2));
fprintf('Inclined warp C26 = %.6f GPa\n',Cinc(2,6));

% ============================================================
% 4. GROUP 2: FOUR THROUGH-THICKNESS SUBCELLS
% ============================================================

% Physical x1 = thickness.
% GMCaniso axis 1 must be prismatic.
%
% Swap physical x1 and x2 so physical thickness becomes
% the discretized solver axis 2.

perm = [2 1 3 5 4 6];

P = eye(6);
P = P(perm,:);

R = struct();

R.NB = 4;
R.NG = 1;

R.h = [0.25 0.25 0.25 0.25];
R.l = 1;

R.C = cell(4,1);
R.alpha = cell(4,1);

% NASA Group 2:
% Matrix - Inclined Tow - Inclined Tow - Matrix

Cblocks = {Cmat,Cinc,Cinc,Cmat};

for k = 1:4

    R.C{k,1} = P*Cblocks{k}*P.';
    R.alpha{k,1} = P*amat;

end

% ============================================================
% 5. FIRST HOMOGENIZATION USING ORIGINAL GMCaniso
% ============================================================

[Cg,ag,As] = GMCaniso(R);

addpath(fullfile(pwd,'Functions','Micromechanics'));

[C_original,~,~] = GMC(struct(),R);

fprintf('\nOriginal GMC vs GMCaniso difference = %.12e\n', ...
    norm(C_original-Cg,'fro'));


% Transform effective stiffness back to physical axes

Cgroup = P.'*Cg*P;

fprintf('\n========== GROUP 2 STIFFNESS ==========\n');

disp(Cgroup);

% ============================================================
% 6. COMPARE WITH NASA
% ============================================================

fprintf('\n%-12s %-15s %-15s %-12s\n', ...
    'Component','GMCaniso','NASA','Error (%)');

fprintf('%s\n',repmat('-',1,58));

components = [1 1; 2 2; 2 6; 6 2; 6 6];

NASA = [6.677;55.800;6.969;5.575;2.269];

for i = 1:size(components,1)

    r = components(i,1);
    c = components(i,2);

    calculated = Cgroup(r,c);
    reference = NASA(i);

    errorPercent = ...
        100*(calculated-reference)/abs(reference);

    fprintf('C%d%d         %12.6f    %12.6f    %+10.3f\n', ...
        r,c,calculated,reference,errorPercent);

end

% ============================================================
% 7. CONSISTENCY CHECKS
% ============================================================

fprintf('\n========== CONSISTENCY CHECKS ==========\n');

symmetryError = norm(Cgroup-Cgroup.','fro');

fprintf('Stiffness symmetry residual = %.6e\n', ...
    symmetryError);

% Volume-weighted strain concentration average

Aavg = zeros(6);

for k = 1:4

    Ak = P.'*As(k,1).A*P;

    Aavg = Aavg + R.h(k)*Ak;

end

Aavg = Aavg/sum(R.h);

fprintf('Strain concentration average residual = %.6e\n', ...
    norm(Aavg-eye(6),'fro'));

fprintf('\n========== FUNCTION LOCATIONS ==========\n');

which TowCfull -all
which GetCFromProps -all
which GMCaniso -all

fprintf('\nVerification completed.\n');

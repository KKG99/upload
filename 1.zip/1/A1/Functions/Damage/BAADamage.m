function varargout = BAADamage(action, varargin)
% +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% Purpose: Unified implementation of the Bednarcyk, Aboudi & Arnold (2010)
%          continuum damage + fracture mechanics model (NASA/TM-2010-216906).
%          Voigt convention: [11, 22, 33, 23, 13, 12] with engineering shear.
%
% Actions:
%   baa = BAADamage('params', constit, overrides)
%   st  = BAADamage('initPoint', C0, baa)
%   [C, d, dS, G] = BAADamage('damagedC', C0, DT, DC, baa)
%   [stOut, changed, newlyFailed] = BAADamage('updatePoint', stIn, epsMech, baa, mode, Cguess)
%   mSt = BAADamage('initMicro', props, opts)
%   [mSt, res] = BAADamage('microStep', mSt, loadInput, DT, isInc0, commitFlag)
%   out = BAADamage('runCoupon', constit, ctrlMode, loadVec, nSteps, opts)
%   tf  = BAADamage('isEnabled', obj, modelTag)
% +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

switch lower(char(action))
    case 'params'
        varargout{1} = defaultParams(varargin{:});
    case 'initpoint'
        varargout{1} = initPoint(varargin{:});
    case 'damagedc'
        [varargout{1:nargout}] = damagedC(varargin{:});
    case 'updatepoint'
        [varargout{1:nargout}] = updatePoint(varargin{:});
    case 'initmicro'
        varargout{1} = initMicro(varargin{:});
    case 'microstep'
        [varargout{1:nargout}] = microStep(varargin{:});
    case 'runcoupon'
        varargout{1} = runCoupon(varargin{:});
    case 'isenabled'
        varargout{1} = isEnabledBAA(varargin{:});
    otherwise
        error(['BAADamage: unknown action "', char(action), '"']);
end

end

% =========================================================================
% Helper: Check whether opt-in BAA continuum damage is active
% =========================================================================
function tf = isEnabledBAA(obj, modelTag)
if nargin >= 2 && ~isempty(modelTag)
    tag = lower(char(modelTag));
    if strcmp(tag, 'nasa'), tf = false; return; end
    if strcmp(tag, 'baa'),  tf = true;  return; end
end
tf = true;
if ~isstruct(obj), return; end
if isfield(obj, 'DamageModel') && ~isempty(obj.DamageModel)
    tag = lower(char(obj.DamageModel));
    if strcmp(tag, 'nasa'), tf = false; return; end
    if strcmp(tag, 'baa'),  tf = true;  return; end
end
if isfield(obj, 'baa') && isstruct(obj.baa) && isfield(obj.baa, 'enabled') && ~obj.baa.enabled
    tf = false; return;
end
if isfield(obj, 'mode') && strcmpi(char(obj.mode), 'elastic')
    tf = false;
end
end

% =========================================================================
% 1) Build BAA parameter struct from constituent + optional overrides
% =========================================================================
function baa = defaultParams(constit, overrides)
if nargin < 1 || isempty(constit), constit = struct(); end
if nargin < 2 || isempty(overrides), overrides = struct(); end

baa = struct();
baa.enabled          = true;
baa.mode             = 'progressive';
baa.longitudinalOnly = false;
baa.interactive      = true;
baa.failCriterion    = 'MaxSERR';   % 'MaxSERR', 'PowerLaw', 'BK'
baa.dMin             = 1.0e-4;
baa.dMax             = 1.0 - 1.0e-4;
baa.compThresh       = -1.0e-9;

% Initiation strains (from allowables if present)
allow = struct();
if isfield(constit, 'allowables') && isstruct(constit.allowables)
    allow = constit.allowables;
end

EL = getNum(constit, 'EL', 1.0);
ET = getNum(constit, 'ET', EL);
vL = getNum(constit, 'vL', 0.3);
vT = getNum(constit, 'vT', vL);
GL = getNum(constit, 'GL', EL / (2.0 * (1.0 + vL)));
GT = ET / (2.0 * (1.0 + vT));

baa.XT = getAllow(allow, 'XT', inf);
baa.XC = -abs(getAllow(allow, 'XC', -inf));

baa.XeT = [ getAllowEps(allow, 'XeT', 'XT', EL, 0.0125), ...
            getAllowEps(allow, 'YeT', 'YT', ET, 0.0125), ...
            getAllowEps(allow, 'ZeT', 'ZT', ET, 0.0125) ];
baa.XeC = [ abs(getAllowEps(allow, 'XeC', 'XC', EL, 0.0287)), ...
            abs(getAllowEps(allow, 'YeC', 'YC', ET, 0.0287)), ...
            abs(getAllowEps(allow, 'ZeC', 'ZC', ET, 0.0287)) ];
baa.Qe  = abs(getAllowEps(allow, 'Qe', 'Q', GT, 0.0443));
baa.Re  = abs(getAllowEps(allow, 'Re', 'R', GL, 0.0443));
baa.Se  = abs(getAllowEps(allow, 'Se', 'S', GL, 0.0443));

% Post-damage evolution (Eq. 34) and scaling (Eqs. 2-3)
baa.AT = 0.70;  baa.BT = 0.82;
baa.AC = 2.00;  baa.BC = 0.96;
baa.bT = [1.0, 1.0, 1.0];
baa.bC = [1.0, 1.0, 1.0];
baa.bS = [0.5, 0.5, 0.5, 0.5, 0.5, 0.5];  % [b42 b43 b51 b53 b61 b62]
baa.blend_b  = true;
baa.blendWin = 0.20;

% Fracture toughness & compressive strain energy (Eqs. 28-33)
baa.GIC   = 800.0;
baa.GIIC  = 2400.0;
baa.GIIIC = 2400.0;
baa.eta   = 1.0;        % PowerLaw exponent or BK eta
baa.WsC   = 1.86e-6;
baa.li    = [9.0e-5, 9.0e-5, 9.0e-5];
baa.V     = (9.0e-5)^3;
baa.energyScale = 1.0e6;

if isfield(constit, 'baa') && isstruct(constit.baa)
    baa = mergeStruct(baa, constit.baa);
end
baa = mergeStruct(baa, overrides);

baa.XeT = expand3(baa.XeT);
baa.XeC = expand3(abs(baa.XeC));
baa.bT  = expand3(baa.bT);
baa.bC  = expand3(baa.bC);
baa.li  = expand3(baa.li);
if numel(baa.bS) == 1
    baa.bS = repmat(baa.bS, 1, 6);
elseif numel(baa.bS) == 3
    baa.bS = [baa.bS(1), baa.bS(1), baa.bS(2), baa.bS(2), baa.bS(3), baa.bS(3)];
end
if ~isfield(baa, 'V') || isempty(baa.V)
    baa.V = baa.li(1) * baa.li(2) * baa.li(3);
end
if isfield(baa, 'XT') && isfinite(baa.XT), baa.XT = abs(baa.XT); end
if isfield(baa, 'XC') && isfinite(baa.XC), baa.XC = -abs(baa.XC); end
if strcmpi(baa.mode, 'elastic'), baa.enabled = false; end
end

function out = mergeStruct(out, src)
if ~isstruct(src), return; end
fn = fieldnames(src);
for k = 1:numel(fn)
    val = src.(fn{k});
    if ~isempty(val)
        out.(fn{k}) = val;
    end
end
end

function v = getNum(s, f, def)
if isstruct(s) && isfield(s, f) && ~isempty(s.(f)) && isfinite(s.(f))
    v = double(s.(f));
else
    v = def;
end
end

function v = getAllow(allow, f, def)
if isstruct(allow) && isfield(allow, f) && ~isempty(allow.(f)) && abs(allow.(f)) < 1e50
    v = double(allow.(f));
else
    v = def;
end
end

function v = getAllowEps(allow, fEps, fSig, E, def)
if isstruct(allow) && isfield(allow, fEps) && ~isempty(allow.(fEps)) && abs(allow.(fEps)) >= 1e50
    v = inf;
elseif isstruct(allow) && isfield(allow, fEps) && ~isempty(allow.(fEps)) && abs(allow.(fEps)) < 1e50
    v = abs(double(allow.(fEps)));
elseif isstruct(allow) && isfield(allow, fSig) && ~isempty(allow.(fSig)) && abs(allow.(fSig)) < 1e50 && E > 0
    v = abs(double(allow.(fSig))) / E;
else
    v = def;
end
end

function vec = expand3(x)
if numel(x) == 1
    vec = [x, x, x];
else
    vec = reshape(x(1:3), 1, 3);
end
end

% =========================================================================
% 2) Initialize single-point material state
% =========================================================================
function state = initPoint(C0, baa)
if nargin < 2 || isempty(baa), baa = defaultParams(); end
C0sym = 0.5 * (C0 + C0.');
eff0  = GetEffPropsFromC(C0sym);

state = struct();
state.C0        = C0sym;
state.S0        = inv(C0sym);
state.G0        = [eff0.G23, eff0.G13, eff0.G12];
state.C         = C0sym;
state.d         = [1.0, 1.0, 1.0];
state.dS        = [1.0, 1.0, 1.0];
state.DT        = [0.0, 0.0, 0.0];
state.DC        = [0.0, 0.0, 0.0];
state.maxDT     = [1.0, 1.0, 1.0];
state.maxDC     = [1.0, 1.0, 1.0];
state.sSign     = [true, true, true];
state.Wacc      = zeros(3, 3);
state.epsPrev   = zeros(6, 1);
state.sigPrev   = zeros(6, 1);
state.initiated = false;
state.failed    = false;
state.failMode  = '';
state.failDir   = 0;
state.last_eD   = [0.0, 0.0, 0.0];
state.last_G    = zeros(3, 3);
state.dMin      = baa.dMin;
end

% =========================================================================
% 3) Damaged stiffness matrix C from DT, DC (Eqs. 1-6)
% =========================================================================
function [C, d, dS, G] = damagedC(C0, DT, DC, baa, S0, G0, sSign)
if nargin < 5 || isempty(S0), S0 = inv(C0); end
if nargin < 6 || isempty(G0), G0 = [C0(4,4), C0(5,5), C0(6,6)]; end
if nargin < 7 || isempty(sSign), sSign = true(1, 3); end

dMin = baa.dMin;
bT   = baa.bT;
bC   = baa.bC;
bS   = baa.bS;

if isfield(baa, 'blend_b') && baa.blend_b && isfield(baa, 'bC_eff')
    bC = baa.bC_eff;
end

D_star = zeros(1, 3);
d      = ones(1, 3);
for i = 1:3
    if sSign(i)
        D_star(i) = DT(i);
        d(i)      = max(dMin, 1.0 - bT(i) * DT(i));
    else
        D_star(i) = DC(i);
        d(i)      = max(dMin, 1.0 - bC(i) * DC(i));
    end
end

S = S0(1:3, 1:3);
for i = 1:3
    S(i, i) = S0(i, i) / d(i);
end
if rcond(S) < 1.0e-12
    C3 = dMin * C0(1:3, 1:3);
else
    C3 = inv(S);
    C3 = 0.5 * (C3 + C3.');
end

dS = [ max(dMin, 1.0 - bS(1) * D_star(2) - bS(2) * D_star(3)), ...
       max(dMin, 1.0 - bS(3) * D_star(1) - bS(4) * D_star(3)), ...
       max(dMin, 1.0 - bS(5) * D_star(1) - bS(6) * D_star(2)) ];
G = dS .* G0;

C = zeros(6, 6);
C(1:3, 1:3) = C3;
C(4, 4) = G(1);
C(5, 5) = G(2);
C(6, 6) = G(3);
end

% =========================================================================
% 4) Single-point damage & failure update ('trial' or 'commit')
% =========================================================================
function [stateOut, changed, newlyFailed] = updatePoint(stateIn, epsMech, baa, mode, Cguess)
if nargin < 4 || isempty(mode), mode = 'commit'; end
if nargin < 5 || isempty(Cguess), Cguess = stateIn.C; end

isCommit    = strcmpi(mode, 'commit');
stateOut    = stateIn;
changed     = false;
newlyFailed = false;
eps         = reshape(epsMech, 6, 1);

if stateIn.failed
    stateOut.C = baa.dMin * stateIn.C0;
    if isCommit
        stateOut.epsPrev = eps;
        stateOut.sigPrev = stateOut.C * eps;
    end
    return
end

if ~baa.enabled
    if isCommit
        stateOut.epsPrev = eps;
        stateOut.sigPrev = stateIn.C * eps;
    end
    return
end

sig = Cguess * eps;

% -- Brittle constituent failure (e.g. longitudinal fiber XT/XC)
if strcmpi(baa.mode, 'brittle')
    trig = false; fDir = 0; fMode = '';
    if baa.longitudinalOnly
        if isfinite(baa.XT) && sig(1) >= baa.XT
            trig = true; fDir = 1; fMode = 'Fiber_XT';
        elseif isfinite(baa.XC) && sig(1) <= baa.XC
            trig = true; fDir = 1; fMode = 'Fiber_XC';
        end
    else
        [eD, sSign] = computeInitiation(eps, sig, baa);
        if any(eD >= 1.0)
            [~, fDir] = max(eD);
            trig = true;
            if sSign(fDir), fMode = 'Brittle_T'; else, fMode = 'Brittle_C'; end
        end
    end
    if trig
        stateOut.C         = baa.dMin * stateIn.C0;
        stateOut.d         = [baa.dMin, baa.dMin, baa.dMin];
        stateOut.dS        = [baa.dMin, baa.dMin, baa.dMin];
        stateOut.initiated = true;
        changed            = true;
        if isCommit
            stateOut.failed   = true;
            stateOut.failMode = fMode;
            stateOut.failDir  = fDir;
            stateOut.epsPrev  = eps;
            stateOut.sigPrev  = stateOut.C * eps;
            newlyFailed       = true;
        end
    elseif isCommit
        stateOut.epsPrev = eps;
        stateOut.sigPrev = stateOut.C * eps;
    end
    return
end

% -- Progressive damage (Eqs. 10-11, 20, 34)
[eD, sSign] = computeInitiation(eps, sig, baa);

DT_new    = stateIn.DT;
DC_new    = stateIn.DC;
maxDT_new = stateIn.maxDT;
maxDC_new = stateIn.maxDC;
bC_eff    = baa.bC;

for i = 1:3
    e_i = eD(i);
    if e_i <= 1.0, continue; end
    if sSign(i)
        if e_i > maxDT_new(i)
            DT_new(i)    = evolveD(DT_new(i), maxDT_new(i), e_i, baa.AT, baa.BT, baa.dMax);
            maxDT_new(i) = e_i;
        end
    else
        if e_i > maxDC_new(i)
            [A_eff, B_eff, bC_i] = blendCompParams(i, eps, baa);
            bC_eff(i)    = bC_i;
            DC_new(i)    = evolveD(DC_new(i), maxDC_new(i), e_i, A_eff, B_eff, baa.dMax);
            maxDC_new(i) = e_i;
        end
    end
end

baaEval = baa;
baaEval.bC_eff = bC_eff;
[C_new, d_new, dS_new] = damagedC(stateIn.C0, DT_new, DC_new, baaEval, stateIn.S0, stateIn.G0, sSign);

relC = max(abs(C_new(:) - stateIn.C(:))) / max(1.0, max(abs(stateIn.C0(:))));
if relC > 1.0e-12, changed = true; end

stateOut.C         = C_new;
stateOut.d         = d_new;
stateOut.dS        = dS_new;
stateOut.DT        = DT_new;
stateOut.DC        = DC_new;
stateOut.maxDT     = maxDT_new;
stateOut.maxDC     = maxDC_new;
stateOut.sSign     = sSign;
stateOut.last_eD   = eD;
stateOut.initiated = stateIn.initiated || any(eD > 1.0);

if ~isCommit, return; end

% -- Commit phase: incremental strain energy release rates & failure (Eqs. 21-33)
sig_final = C_new * eps;
dD_T = max(0.0, DT_new - stateIn.DT);
dD_C = max(0.0, DC_new - stateIn.DC);
dD   = dD_T + dD_C;

dW_mat = max(0.0, 0.5 * (stateIn.sigPrev .* eps - stateIn.epsPrev .* sig_final));
dW_mat(4:6) = 0.5 * dW_mat(4:6);

shearPairs = [6, 5; 4, 6; 5, 4];  % Table 1 / Eq. (25)
otherIdx   = [2, 3; 3, 1; 1, 2];
dWhat = zeros(3, 3);
G_mat = zeros(3, 3);
Wacc  = stateIn.Wacc;

failTrig = false;
fMode    = '';
fDir     = 0;

for i = 1:3
    dD_i = dD(i);
    if dD_i <= 0.0, continue; end

    dWhat(i, 1) = dW_mat(i);
    for m = 1:2
        s_comp = shearPairs(i, m);
        j_pair = otherIdx(i, m);
        denom  = dD_i + dD(j_pair);
        if denom > 0.0
            dWhat(i, m + 1) = dW_mat(s_comp) * (dD_i / denom);
        end
    end

    if sSign(i)
        if dD_i > 1.0e-12
            if baa.bT(i) > 0.0
                G_mat(i, 1) = (baa.li(i) / baa.bT(i)) * (dWhat(i, 1) / dD_i) * baa.energyScale;
            end
            for m = 1:2
                bS_im = getShearScale(i, m + 1, baa);
                if bS_im > 0.0
                    G_mat(i, m + 1) = (baa.li(i) / bS_im) * (dWhat(i, m + 1) / dD_i) * baa.energyScale;
                end
            end
            [tf, critName] = checkTensileFail(G_mat(i, 1), G_mat(i, 2), G_mat(i, 3), baa);
            if tf && ~failTrig
                failTrig = true; fMode = critName; fDir = i;
            end
        end
    else
        Wacc(i, :) = Wacc(i, :) + dWhat(i, :) * (baa.V * baa.energyScale);
        if sum(Wacc(i, :)) >= baa.WsC && ~failTrig
            failTrig = true; fMode = 'Compressive_WsC'; fDir = i;
        end
    end
end

stateOut.Wacc   = Wacc;
stateOut.last_G = G_mat;
if failTrig
    stateOut.C        = baa.dMin * stateIn.C0;
    stateOut.d        = [baa.dMin, baa.dMin, baa.dMin];
    stateOut.dS       = [baa.dMin, baa.dMin, baa.dMin];
    stateOut.failed   = true;
    stateOut.failMode = fMode;
    stateOut.failDir  = fDir;
    changed           = true;
    newlyFailed       = true;
    sig_final         = stateOut.C * eps;
end

stateOut.epsPrev = eps;
stateOut.sigPrev = sig_final;
end

function [eD, sSign] = computeInitiation(eps, sig, baa)
eD    = zeros(1, 3);
sSign = true(1, 3);
sigScale = max(1.0, max(abs(sig(1:3))));
thresh   = baa.compThresh * sigScale;
shearMap = [5, 6; 4, 6; 5, 4];
shearDen = [baa.Re, baa.Se; baa.Qe, baa.Se; baa.Re, baa.Qe];

for i = 1:3
    sSign(i) = (sig(i) >= thresh);
    if sSign(i), nDen = baa.XeT(i); else, nDen = baa.XeC(i); end
    t1 = eps(i) / nDen;
    if baa.interactive
        t2 = eps(shearMap(i, 1)) / shearDen(i, 1);
        t3 = eps(shearMap(i, 2)) / shearDen(i, 2);
        eD(i) = sqrt(t1*t1 + t2*t2 + t3*t3);
    else
        eD(i) = abs(t1);
    end
end
end

function D_new = evolveD(D0, e0, e1, A, B, dMax)
D_new = (e0 * D0 + (e1 - e0) + A * B * (exp(-e1 / B) - exp(-e0 / B))) / e1;
D_new = min(dMax, max(D0, D_new));
end

function [A_eff, B_eff, bC_eff] = blendCompParams(i, eps, baa)
shearMap = [5, 6; 4, 6; 5, 4];
shearDen = [baa.Re, baa.Se; baa.Qe, baa.Se; baa.Re, baa.Qe];
s_i = sqrt((eps(shearMap(i, 1)) / shearDen(i, 1))^2 + (eps(shearMap(i, 2)) / shearDen(i, 2))^2);
if s_i <= 1.0e-12
    A_eff = baa.AC; B_eff = baa.BC; bC_eff = baa.bC(i);
else
    cRatio = abs(eps(i) / baa.XeC(i));
    w = min(1.0, max(0.0, 1.0 - (cRatio / s_i) / baa.blendWin));
    A_eff = w * baa.AT + (1.0 - w) * baa.AC;
    B_eff = w * baa.BT + (1.0 - w) * baa.BC;
    if isfield(baa, 'blend_b') && baa.blend_b
        bC_eff = w * baa.bT(i) + (1.0 - w) * baa.bC(i);
    else
        bC_eff = baa.bC(i);
    end
end
end

function bS_im = getShearScale(i, mCol, baa)
if i == 1
    if mCol == 2, bS_im = baa.bS(5); else, bS_im = baa.bS(3); end
elseif i == 2
    if mCol == 2, bS_im = baa.bS(1); else, bS_im = baa.bS(6); end
else
    if mCol == 2, bS_im = baa.bS(4); else, bS_im = baa.bS(2); end
end
end

function [tf, critName] = checkTensileFail(GI, GII, GIII, baa)
tf = false; critName = '';
switch lower(char(baa.failCriterion))
    case 'maxserr'
        if GI >= baa.GIC
            tf = true; critName = 'MaxSERR_GI';
        elseif GII >= baa.GIIC
            tf = true; critName = 'MaxSERR_GII';
        elseif GIII >= baa.GIIIC
            tf = true; critName = 'MaxSERR_GIII';
        end
    case 'powerlaw'
        eta = baa.eta;
        val = (max(0.0, GI) / baa.GIC)^eta + (max(0.0, GII) / baa.GIIC)^eta + (max(0.0, GIII) / baa.GIIIC)^eta;
        if val >= 1.0, tf = true; critName = 'PowerLaw'; end
    case 'bk'
        Gt = max(0.0, GI) + max(0.0, GII) + max(0.0, GIII);
        if Gt > 0.0
            Gs = max(0.0, GII) + max(0.0, GIII);
            Gc = baa.GIC + (baa.GIIC - baa.GIC) * (Gs / Gt)^baa.eta;
            if Gt >= Gc, tf = true; critName = 'BK'; end
        end
    otherwise
        error(['BAADamage: unknown failCriterion ', char(baa.failCriterion)]);
end
end

% =========================================================================
% 5) Initialize micromechanics-level BAA state
% =========================================================================
function wpBAA = loadWeaveProblemBAA()
wpBAA = struct('Fiber', struct(), 'Matrix', struct(), 'Interface', struct(), 'DamageFactor', []);
try
    a1Dir = fileparts(fileparts(fileparts(mfilename('fullpath'))));
    wFile = fullfile(a1Dir, 'WeaveProps', 'WeaveProblemDef.m');
    if exist(wFile, 'file')
        if ~exist('WeaveProblemDef', 'file')
            addpath(fullfile(a1Dir, 'WeaveProps'));
        end
        Wp = WeaveProblemDef();
        if isfield(Wp, 'DamageFactor') && ~isempty(Wp.DamageFactor)
            wpBAA.DamageFactor = Wp.DamageFactor;
        end
        if isfield(Wp, 'BAA') && isstruct(Wp.BAA)
            if isfield(Wp.BAA, 'Fiber') && isstruct(Wp.BAA.Fiber),         wpBAA.Fiber = Wp.BAA.Fiber; end
            if isfield(Wp.BAA, 'Matrix') && isstruct(Wp.BAA.Matrix),       wpBAA.Matrix = Wp.BAA.Matrix; end
            if isfield(Wp.BAA, 'Interface') && isstruct(Wp.BAA.Interface), wpBAA.Interface = Wp.BAA.Interface; end
        end
    end
catch
end
end

function ov = applyDamageFactorDefault(ov, df)
if isempty(df) || ~isfinite(df) || df <= 0 || df >= 1, return; end
if ~isfield(ov, 'dMin') || isempty(ov.dMin), ov.dMin = df; end
if ~isfield(ov, 'dMax') || isempty(ov.dMax), ov.dMax = 1.0 - df; end
end

function mState = initMicro(props, opts)
if nargin < 2 || isempty(opts), opts = struct(); end

mState = struct();
mState.propsInit = props;
mState.propsCurr = props;
mState.incCount  = 0;

wpDef = loadWeaveProblemBAA();
ovF = wpDef.Fiber;
ovM = wpDef.Matrix;
ovI = wpDef.Interface;
if isempty(fieldnames(ovI)), ovI = ovM; end

if isfield(opts, 'Fiber') && isstruct(opts.Fiber),         ovF = mergeStruct(ovF, opts.Fiber); end
if isfield(opts, 'Matrix') && isstruct(opts.Matrix),       ovM = mergeStruct(ovM, opts.Matrix); end
if isfield(opts, 'Interface') && isstruct(opts.Interface), ovI = mergeStruct(ovI, opts.Interface); end
if isfield(opts, 'baaF') && isstruct(opts.baaF),           ovF = mergeStruct(ovF, opts.baaF); end
if isfield(opts, 'baaM') && isstruct(opts.baaM),           ovM = mergeStruct(ovM, opts.baaM); end
if isfield(opts, 'baaI') && isstruct(opts.baaI),           ovI = mergeStruct(ovI, opts.baaI); end

df = getOpt(opts, 'DamageFactor', wpDef.DamageFactor);
ovF = applyDamageFactorDefault(ovF, df);
ovM = applyDamageFactorDefault(ovM, df);
ovI = applyDamageFactorDefault(ovI, df);

mState.baaF = defaultParams(props.Fiber, ovF);
mState.baaM = defaultParams(props.Matrix, ovM);
if isfield(props, 'Interface') && isstruct(props.Interface)
    mState.baaI = defaultParams(props.Interface, ovI);
else
    mState.baaI = struct('enabled', false, 'mode', 'elastic');
end

mState.opts.tol                = getOpt(opts, 'tol', 2.0e-4);
mState.opts.maxIter            = getOpt(opts, 'maxIter', 25);
mState.opts.maxFailPass        = getOpt(opts, 'maxFailPass', 10);
mState.opts.redistributeOnFail = logical(getOpt(opts, 'redistributeOnFail', true));
mState.opts.maxStrainCap       = getOpt(opts, 'maxStrainCap', 1.0);

theory = char(props.micro);
if strcmp(theory, 'GMC') || strcmp(theory, 'HFGMC') || strcmp(theory, 'MOC') || strcmp(theory, 'MOCu')
    mState.type = 'bg';
    RUC = props.RUC;
    NB = RUC.NB; NG = RUC.NG;
    mState.NB = NB; mState.NG = NG;
    mState.subType = RUC.matsCh;
    mState.subArea = RUC.h(:) * RUC.l(:).';

    C_F = GetCFromProps(props.Fiber);
    C_M = GetCFromProps(props.Matrix);
    if isfield(props, 'Interface'), C_I = GetCFromProps(props.Interface); else, C_I = C_M; end

    sub(NB, NG) = initPoint(C_M, mState.baaM);
    for b = 1:NB
        for g = 1:NG
            switch RUC.matsCh(b, g)
                case {'F', '1'}, sub(b, g) = initPoint(C_F, mState.baaF);
                case {'I', '3'}, sub(b, g) = initPoint(C_I, mState.baaI);
                otherwise,       sub(b, g) = initPoint(C_M, mState.baaM);
            end
        end
    end
    mState.sub = sub;
else
    mState.type = 'FM';
    mState.F = initPoint(GetCFromProps(props.Fiber), mState.baaF);
    mState.M = initPoint(GetCFromProps(props.Matrix), mState.baaM);
end
end

% =========================================================================
% 6) Advance (or trial-evaluate) one micromechanics increment
% =========================================================================
function [mStateOut, res] = microStep(mStateIn, loadInput, DT, isInc0, commitFlag)
if nargin < 3 || isempty(DT), DT = 0; end
if nargin < 4 || isempty(isInc0), isInc0 = false; end
if nargin < 5 || isempty(commitFlag), commitFlag = true; end

mStateOut  = mStateIn;
opts       = mStateIn.opts;
isLoadCtrl = isstruct(loadInput);

if isInc0
    propsWork = mStateIn.propsCurr;
    [SG, FullGlobalStrain, epsth, Stress, limitReached] = solveGlobal(propsWork, loadInput, DT, isLoadCtrl, opts.maxStrainCap);
    mf = MicroFields(FullGlobalStrain, DT, propsWork, struct());
    if commitFlag
        if strcmp(mStateIn.type, 'bg')
            for b = 1:mStateIn.NB
                for g = 1:mStateIn.NG
                    mStateOut.sub(b, g).epsPrev = mf.MicroFields(b, g).strain - mf.MicroFields(b, g).thstrain;
                    mStateOut.sub(b, g).sigPrev = mf.MicroFields(b, g).stress;
                end
            end
        else
            mStateOut.F.epsPrev = mf.MicroFieldsF.strain - mf.MicroFieldsF.thstrain;
            mStateOut.F.sigPrev = mf.MicroFieldsF.stress;
            mStateOut.M.epsPrev = mf.MicroFieldsM.strain - mf.MicroFieldsM.thstrain;
            mStateOut.M.sigPrev = mf.MicroFieldsM.stress;
        end
        mStateOut.incCount = mStateIn.incCount + 1;
    end
    res = packRes(propsWork, SG, FullGlobalStrain, epsth, Stress, mf, mStateOut, false, zeros(3,3), limitReached);
    return
end

propsWork    = mStateIn.propsCurr;
limitReached = false;

if strcmp(mStateIn.type, 'bg')
    NB = mStateIn.NB; NG = mStateIn.NG;
    commSub    = mStateIn.sub;
    trialSub   = commSub;
    candSub    = commSub;
    lockedFail = false(NB, NG);
    anyAlreadyDamOrInit = false;
    for b = 1:NB
        for g = 1:NG
            lockedFail(b, g) = commSub(b, g).failed;
            if commSub(b, g).initiated || commSub(b, g).failed
                anyAlreadyDamOrInit = true;
            end
        end
    end
    lockedState = commSub;

    RUCwork = propsWork.RUC;
    RUCwork.C     = cell(NB, NG);
    RUCwork.alpha = cell(NB, NG);
    for b = 1:NB
        for g = 1:NG
            RUCwork.C{b, g}     = commSub(b, g).C;
            RUCwork.alpha{b, g} = propsWork.As(b, g).alpha;
        end
    end
    normC0 = max(1.0, max(abs(mStateIn.propsInit.Cstar(:))));
    anyNewFailureOverall = false;
    maxPasses = opts.maxFailPass;
    if ~commitFlag || ~opts.redistributeOnFail, maxPasses = 1; end

    for fPass = 1:maxPasses
        anyChangedAnyIter = false;
        for it = 1:opts.maxIter
            [SG, FullGlobalStrain, epsth, Stress, limitReached] = solveGlobal(propsWork, loadInput, DT, isLoadCtrl, opts.maxStrainCap);
            if limitReached, break; end
            mf = MicroFields(FullGlobalStrain, DT, propsWork, struct());

            anyChanged = false;
            maxRelC    = 0.0;
            for b = 1:NB
                for g = 1:NG
                    if lockedFail(b, g)
                        trialSub(b, g) = lockedState(b, g);
                    else
                        baa_bg  = getSubBAA(mStateIn, mStateIn.subType(b, g));
                        epsMech = mf.MicroFields(b, g).strain - mf.MicroFields(b, g).thstrain;
                        prevC   = RUCwork.C{b, g};
                        [trialSub(b, g), ~] = updatePoint(commSub(b, g), epsMech, baa_bg, 'trial', prevC);
                        C_cand  = trialSub(b, g).C;
                        relDiff = max(abs(C_cand(:) - prevC(:))) / max(1.0, max(abs(commSub(b, g).C0(:))));
                        if it >= 10 && relDiff > opts.tol
                            C_cand = 0.5 * C_cand + 0.5 * prevC;
                            trialSub(b, g).C = C_cand;
                        end
                        if relDiff > opts.tol
                            anyChanged = true;
                            anyChangedAnyIter = true;
                        end
                        maxRelC = max(maxRelC, relDiff);
                    end
                    RUCwork.C{b, g} = trialSub(b, g).C;
                end
            end

            if ~anyChanged, break; end

            propsNext = rehomogRUC(propsWork, RUCwork);
            CstarDiff = max(abs(propsNext.Cstar(:) - propsWork.Cstar(:))) / normC0;
            propsWork = propsNext;
            if CstarDiff < opts.tol && maxRelC < 5.0 * opts.tol, break; end
        end

        if limitReached, break; end

        if ~anyChangedAnyIter && ~anyAlreadyDamOrInit && fPass == 1
            if commitFlag
                for b = 1:NB
                    for g = 1:NG
                        candSub(b, g).epsPrev = mf.MicroFields(b, g).strain - mf.MicroFields(b, g).thstrain;
                        candSub(b, g).sigPrev = mf.MicroFields(b, g).stress;
                    end
                end
            else
                res = packRes(propsWork, SG, FullGlobalStrain, epsth, Stress, mf, mStateIn, false, zeros(3,3), false);
                res.trialSub = trialSub;
                return
            end
            break
        end

        [SG, FullGlobalStrain, epsth, Stress, limitReached] = solveGlobal(propsWork, loadInput, DT, isLoadCtrl, opts.maxStrainCap);
        mf = MicroFields(FullGlobalStrain, DT, propsWork, struct());

        if ~commitFlag
            res = packRes(propsWork, SG, FullGlobalStrain, epsth, Stress, mf, mStateIn, false, zeros(3,3), limitReached);
            res.trialSub = trialSub;
            return
        end

        newFailThisPass = false;
        candSub = trialSub;
        for b = 1:NB
            for g = 1:NG
                baa_bg  = getSubBAA(mStateIn, mStateIn.subType(b, g));
                epsMech = mf.MicroFields(b, g).strain - mf.MicroFields(b, g).thstrain;
                if lockedFail(b, g)
                    candSub(b, g) = updatePoint(lockedState(b, g), epsMech, baa_bg, 'commit');
                else
                    [candSub(b, g), ~, nf] = updatePoint(commSub(b, g), epsMech, baa_bg, 'commit', trialSub(b, g).C);
                    if nf
                        newFailThisPass      = true;
                        anyNewFailureOverall = true;
                        lockedFail(b, g)     = true;
                        lockedState(b, g)    = candSub(b, g);
                        RUCwork.C{b, g}      = candSub(b, g).C;
                    end
                end
            end
        end

        if newFailThisPass && opts.redistributeOnFail && fPass < maxPasses
            propsWork = rehomogRUC(propsWork, RUCwork);
            continue
        end
        break
    end

    if limitReached
        [SG, FullGlobalStrain, epsth, Stress, ~] = solveGlobal(mStateIn.propsCurr, loadInput, DT, isLoadCtrl, inf);
        mf = MicroFields(FullGlobalStrain, DT, mStateIn.propsCurr, struct());
        res = packRes(mStateIn.propsCurr, SG, FullGlobalStrain, epsth, Stress, mf, mStateIn, false, zeros(3,3), true);
        return
    end

    if anyNewFailureOverall
        propsWork = rehomogRUC(propsWork, RUCwork);
        if ~isLoadCtrl
            [SG, FullGlobalStrain, epsth, Stress, ~] = solveGlobal(propsWork, loadInput, DT, false, inf);
            mf = MicroFields(FullGlobalStrain, DT, propsWork, struct());
        end
    end

    avgG_M = zeros(3, 3); areaM = 0.0;
    for b = 1:NB
        for g = 1:NG
            if mStateIn.subType(b, g) == 'M'
                a_bg = mStateIn.subArea(b, g);
                areaM = areaM + a_bg;
                avgG_M = avgG_M + a_bg * candSub(b, g).last_G;
            end
        end
    end
    if areaM > 0.0, avgG_M = avgG_M / areaM; end

    mStateOut.sub       = candSub;
    mStateOut.propsCurr = propsWork;
    mStateOut.incCount  = mStateIn.incCount + 1;
    res = packRes(propsWork, SG, FullGlobalStrain, epsth, Stress, mf, mStateOut, anyNewFailureOverall, avgG_M, false);

else
    commF = mStateIn.F; commM = mStateIn.M;
    trialF = commF; trialM = commM;
    normC0 = max(1.0, max(abs(mStateIn.propsInit.Cstar(:))));

    for it = 1:opts.maxIter
        [SG, FullGlobalStrain, epsth, Stress, limitReached] = solveGlobal(propsWork, loadInput, DT, isLoadCtrl, opts.maxStrainCap);
        if limitReached, break; end
        mf = MicroFields(FullGlobalStrain, DT, propsWork, struct());
        epsF = mf.MicroFieldsF.strain - mf.MicroFieldsF.thstrain;
        epsM = mf.MicroFieldsM.strain - mf.MicroFieldsM.thstrain;

        [trialF, chF] = updatePoint(commF, epsF, mStateIn.baaF, 'trial', trialF.C);
        [trialM, chM] = updatePoint(commM, epsM, mStateIn.baaM, 'trial', trialM.C);
        if ~chF && ~chM, break; end

        propsNext = rehomogFM(propsWork, trialF.C, trialM.C);
        CstarDiff = max(abs(propsNext.Cstar(:) - propsWork.Cstar(:))) / normC0;
        propsWork = propsNext;
        if CstarDiff < opts.tol, break; end
    end

    if limitReached
        [SG, FullGlobalStrain, epsth, Stress, ~] = solveGlobal(mStateIn.propsCurr, loadInput, DT, isLoadCtrl, inf);
        mf = MicroFields(FullGlobalStrain, DT, mStateIn.propsCurr, struct());
        res = packRes(mStateIn.propsCurr, SG, FullGlobalStrain, epsth, Stress, mf, mStateIn, false, zeros(3,3), true);
        return
    end

    [SG, FullGlobalStrain, epsth, Stress, ~] = solveGlobal(propsWork, loadInput, DT, isLoadCtrl, inf);
    mf = MicroFields(FullGlobalStrain, DT, propsWork, struct());
    if ~commitFlag
        res = packRes(propsWork, SG, FullGlobalStrain, epsth, Stress, mf, mStateIn, false, zeros(3,3), false);
        return
    end

    epsF = mf.MicroFieldsF.strain - mf.MicroFieldsF.thstrain;
    epsM = mf.MicroFieldsM.strain - mf.MicroFieldsM.thstrain;
    [candF, ~, nfF] = updatePoint(commF, epsF, mStateIn.baaF, 'commit', trialF.C);
    [candM, ~, nfM] = updatePoint(commM, epsM, mStateIn.baaM, 'commit', trialM.C);
    anyNF = nfF || nfM;
    if anyNF, propsWork = rehomogFM(propsWork, candF.C, candM.C); end
    mStateOut.F = candF; mStateOut.M = candM;
    mStateOut.propsCurr = propsWork;
    mStateOut.incCount  = mStateIn.incCount + 1;
    res = packRes(propsWork, SG, FullGlobalStrain, epsth, Stress, mf, mStateOut, anyNF, candM.last_G, false);
end
end

function baa_bg = getSubBAA(mState, ch)
switch ch
    case {'F', '1'}, baa_bg = mState.baaF;
    case {'I', '3'}, baa_bg = mState.baaI;
    otherwise,       baa_bg = mState.baaM;
end
end

function [SG, EG, epsth, Stress, limitReached] = solveGlobal(props, loadInput, DT, isLoadCtrl, maxStrainCap)
if isfield(props, 'CTEs') && numel(props.CTEs) == 6
    epsth = DT * reshape(props.CTEs, 6, 1);
else
    epsth = DT * [props.a1; props.a2; props.a3; 0; 0; 0];
end
if isLoadCtrl
    B = -props.Cstar * epsth;
    [SG, EG] = SolveLoading(6, props.Cstar, B, loadInput);
    Stress = props.Cstar * (EG - epsth);
    limitReached = any(~isfinite(EG)) || (max(abs(EG)) > maxStrainCap);
else
    EG = reshape(loadInput, 6, 1);
    Stress = props.Cstar * (EG - epsth);
    SG = Stress;
    limitReached = any(~isfinite(Stress));
end
end

function propsNew = rehomogRUC(props, RUC)
propsNew = props; propsNew.RUC = RUC;
Constits.Fiber = props.Fiber; Constits.Matrix = props.Matrix;
if isfield(props, 'Interface'), Constits.Interface = props.Interface; end
if strcmp(char(props.micro), 'HFGMC')
    [Cstar, CTEs, As] = HFGMC(Constits, RUC);
else
    [Cstar, CTEs, As] = GMC(Constits, RUC);
end
propsNew.Cstar = Cstar; propsNew.CTEs = CTEs; propsNew.As = As;
eff = GetEffPropsFromC(Cstar);
propsNew.E1 = eff.E1; propsNew.E2 = eff.E2; propsNew.E3 = eff.E3;
propsNew.v12 = eff.v12; propsNew.v13 = eff.v13; propsNew.v23 = eff.v23;
propsNew.G23 = eff.G23; propsNew.G13 = eff.G13; propsNew.G12 = eff.G12;
propsNew.a1 = CTEs(1); propsNew.a2 = CTEs(2); propsNew.a3 = CTEs(3);
end

function propsNew = rehomogFM(props, Cf, Cm)
propsNew = props;
effF = GetEffPropsFromC(Cf); effM = GetEffPropsFromC(Cm);
Ftmp = props.Fiber;
Ftmp.EL = effF.E1; Ftmp.ET = 0.5*(effF.E2+effF.E3);
Ftmp.vL = 0.5*(effF.v12+effF.v13); Ftmp.vT = effF.v23; Ftmp.GL = 0.5*(effF.G12+effF.G13);
Ftmp.E1 = effF.E1; Ftmp.E2 = effF.E2; Ftmp.E3 = effF.E3;
Ftmp.v12 = effF.v12; Ftmp.v13 = effF.v13; Ftmp.v23 = effF.v23;
Ftmp.G12 = effF.G12; Ftmp.G13 = effF.G13; Ftmp.G23 = effF.G23;
Mtmp = props.Matrix;
Mtmp.EL = effM.E1; Mtmp.ET = 0.5*(effM.E2+effM.E3);
Mtmp.vL = 0.5*(effM.v12+effM.v13); Mtmp.vT = effM.v23; Mtmp.GL = 0.5*(effM.G12+effM.G13);
Mtmp.E1 = effM.E1; Mtmp.E2 = effM.E2; Mtmp.E3 = effM.E3;
Mtmp.v12 = effM.v12; Mtmp.v13 = effM.v13; Mtmp.v23 = effM.v23;
Mtmp.G12 = effM.G12; Mtmp.G13 = effM.G13; Mtmp.G23 = effM.G23;
propsNew.Fiber = Ftmp; propsNew.Matrix = Mtmp;
switch char(props.micro)
    case 'Voigt', [Cstar, CTEs, Af, Am, ATf, ATm] = Voigt(Ftmp, Mtmp, props.Vf);
    case 'Reuss', [Cstar, CTEs, Af, Am, ATf, ATm] = Reuss(Ftmp, Mtmp, props.Vf);
    otherwise,    [Cstar, CTEs, Af, Am, ATf, ATm] = MT(Ftmp, Mtmp, props.Vf);
end
propsNew.Cstar = Cstar; propsNew.CTEs = CTEs;
propsNew.Af = Af; propsNew.Am = Am; propsNew.ATf = ATf; propsNew.ATm = ATm;
eff = GetEffPropsFromC(Cstar);
propsNew.E1 = eff.E1; propsNew.E2 = eff.E2; propsNew.E3 = eff.E3;
propsNew.v12 = eff.v12; propsNew.v13 = eff.v13; propsNew.v23 = eff.v23;
propsNew.G23 = eff.G23; propsNew.G13 = eff.G13; propsNew.G12 = eff.G12;
propsNew.a1 = CTEs(1); propsNew.a2 = CTEs(2); propsNew.a3 = CTEs(3);
end

function res = packRes(props, SG, EG, epsth, Stress, mf, mState, newlyFailed, avgG_M, limitReached)
res = struct();
res.props = props; res.Cstar = props.Cstar;
res.CTEs = [props.a1; props.a2; props.a3; 0; 0; 0];
if isfield(props, 'CTEs'), res.CTEs = props.CTEs; end
res.SG = SG; res.FullGlobalStrain = EG; res.epsth = epsth;
res.Stress = Stress; res.MicroFields = mf;
res.newlyFailed = newlyFailed; res.avgG_M = avgG_M; res.limitReached = limitReached;
nInit = 0; nDam = 0; nFail = 0; maxG = 0;
if strcmp(mState.type, 'bg')
    for b = 1:mState.NB
        for g = 1:mState.NG
            st = mState.sub(b, g);
            if st.initiated, nInit = nInit + 1; end
            if any(st.DT > 0) || any(st.DC > 0) || st.failed, nDam = nDam + 1; end
            if st.failed, nFail = nFail + 1; end
            if mState.subType(b, g) == 'M', maxG = max(maxG, max(st.last_G(:))); end
        end
    end
else
    if mState.F.initiated || mState.M.initiated, nInit = 1; end
    if mState.M.failed, nFail = nFail + 1; end
    maxG = max(mState.M.last_G(:));
end
res.nInitSub = nInit; res.nDamSub = nDam; res.nFailSub = nFail; res.maxG_M = maxG;
end

% =========================================================================
% 7) Single-point monolithic coupon / envelope driver
% =========================================================================
function out = runCoupon(constit, ctrlMode, loadVec, nSteps, opts)
if nargin < 5 || isempty(opts), opts = struct(); end
dr         = getOpt(opts, 'dr', 0.25);
pureStrain = logical(getOpt(opts, 'pureStrain', false));
maxStrain  = getOpt(opts, 'maxStrain', 2.0);
stopOnFail = logical(getOpt(opts, 'stopOnFail', true));

baa = defaultParams(constit);
C0  = GetCFromProps(constit);
st  = initPoint(C0, baa);

loadVec = reshape(loadVec, 6, 1);
epsHist = zeros(nSteps + 1, 6); sigHist = zeros(nSteps + 1, 6);
DTHist  = zeros(nSteps + 1, 3); DCHist  = zeros(nSteps + 1, 3);
initSig = nan(6, 1); initEps = nan(6, 1);
failSig = nan(6, 1); failEps = nan(6, 1);
failReason = ''; count = 1;

if strcmpi(ctrlMode, 'strain')
    active = (abs(loadVec) > 0); free = ~active; eps = zeros(6, 1);
    for k = 1:nSteps
        eps(active) = (k / nSteps) * loadVec(active);
        if ~pureStrain && any(free)
            for it = 1:25
                st_tr = updatePoint(st, eps, baa, 'trial');
                C = st_tr.C;
                ef = -C(free, free) \ (C(free, active) * eps(active));
                if max(abs(ef - eps(free))) < 1e-10, eps(free) = ef; break; end
                eps(free) = ef;
            end
        end
        st_tr = updatePoint(st, eps, baa, 'trial');
        [st_new, ~, nfail] = updatePoint(st, eps, baa, 'commit', st_tr.C);
        sig = st_tr.C * eps;
        count = count + 1;
        epsHist(count,:) = eps.'; sigHist(count,:) = sig.';
        DTHist(count,:) = st_new.DT; DCHist(count,:) = st_new.DC;
        if any(isnan(initSig)) && st_new.initiated, initSig = sig; initEps = eps; end
        st = st_new;
        if nfail
            failSig = sig; failEps = eps; failReason = st_new.failMode;
            if stopOnFail, break; end
        end
    end
elseif strcmpi(ctrlMode, 'stress')
    dNorm = norm(loadVec);
    if dNorm == 0, error('BAADamage:runCoupon loadVec cannot be zero in stress mode'); end
    dir = loadVec / dNorm; r = 0;
    for k = 1:nSteps
        r = r + dr; sig_target = r * dir;
        eps_k = st.C \ sig_target;
        st_tr = updatePoint(st, eps_k, baa, 'trial');
        conv  = (norm(st_tr.C * eps_k - sig_target) < 1e-6 * max(1.0, r));
        if ~conv
            for it = 1:4
                en = st_tr.C \ sig_target;
                if max(abs(en - eps_k)) < 1e-8 && norm(en) <= maxStrain
                    eps_k = en; st_tr = updatePoint(st, eps_k, baa, 'trial');
                    conv = (norm(st_tr.C * eps_k - sig_target) < 1e-5 * max(1.0, r));
                    break
                end
                eps_k = 0.7 * en + 0.3 * eps_k;
                if norm(eps_k) > maxStrain, break; end
                st_tr = updatePoint(st, eps_k, baa, 'trial');
            end
        end
        if ~conv && norm(eps_k) <= maxStrain
            for it = 1:12
                st_tr = updatePoint(st, eps_k, baa, 'trial');
                sig_k = st_tr.C * eps_k; res = sig_k - sig_target;
                if norm(res) < 1e-6 * max(1.0, r), conv = true; break; end
                Kt = zeros(6); h = 1e-7;
                for j = 1:6
                    ep = eps_k; ep(j) = ep(j) + h;
                    stp = updatePoint(st, ep, baa, 'trial');
                    Kt(:, j) = (stp.C * ep - sig_k) / h;
                end
                if rcond(Kt) < 1e-12, break; end
                deps = -Kt \ res;
                if norm(deps) > 0.25, deps = deps * (0.25 / norm(deps)); end
                eps_k = eps_k + deps;
                if norm(eps_k) > maxStrain, break; end
            end
        end
        if ~conv
            failSig = st.sigPrev; failEps = st.epsPrev; failReason = 'LimitPoint'; break
        end
        st_tr = updatePoint(st, eps_k, baa, 'trial');
        [st_new, ~, nfail] = updatePoint(st, eps_k, baa, 'commit', st_tr.C);
        sig = st_tr.C * eps_k;
        count = count + 1;
        epsHist(count,:) = eps_k.'; sigHist(count,:) = sig.';
        DTHist(count,:) = st_new.DT; DCHist(count,:) = st_new.DC;
        if any(isnan(initSig)) && st_new.initiated, initSig = sig; initEps = eps_k; end
        st = st_new;
        if nfail
            failSig = sig; failEps = eps_k; failReason = st_new.failMode;
            if stopOnFail, break; end
        end
    end
else
    error(['BAADamage:runCoupon unknown ctrlMode ', ctrlMode]);
end

out = struct('epsHist', epsHist(1:count,:), 'sigHist', sigHist(1:count,:), ...
             'DTHist', DTHist(1:count,:), 'DCHist', DCHist(1:count,:), ...
             'initSig', initSig, 'initEps', initEps, ...
             'failSig', failSig, 'failEps', failEps, ...
             'failReason', failReason, 'state', st);
end

function v = getOpt(s, f, def)
if isstruct(s) && isfield(s, f) && ~isempty(s.(f))
    v = s.(f);
else
    v = def;
end
end

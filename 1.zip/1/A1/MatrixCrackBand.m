
function p = MatrixCrackBand(action,varargin)
% Ricks et al. (2021,2022), fixed-lc mixed-mode adaptation.
% Units: MPa, N/mm, mm. Voigt: 11 22 33 23 13 12.
% Sii=S0ii/D is the documented normal-compliance approximation.
% Both tangential strains combined; no independent mode-III law.

switch lower(action)

    case 'init'

        m=varargin{1};
        cb=varargin{2};

        E=m.EL;
        nu=m.vL;
        G=E/(2*(1+nu));

        x=[cb.Xm_MPa cb.Ym_MPa cb.GIC_N_per_mm ...
           cb.GIIC_N_per_mm cb.lc_mm cb.residual];

        assert(numel(x)==6 && all(isfinite(x)) && all(x>0) && ...
            cb.residual<1,'Supply positive crack-band inputs.');

        assert(isfinite(E) && E>0 && nu>-1 && nu<0.5, ...
            'Invalid matrix elastic constants.');

        assert(abs(m.ET/E-1)<1e-6 && abs(m.vT-nu)<1e-6 && ...
            abs(m.GL/G-1)<1e-6,'Matrix must be elastically isotropic.');

        C=GetCFromProps(m);
        S=C\eye(6);

        p=struct('C',C,'S0',S,'E',E,'G',G, ...
            'Xm',x(1),'Ym',x(2),'GIC',x(3),'GIIC',x(4), ...
            'lc',x(5),'floor',x(6),'plane',0,'shears',[], ...
            'e0',NaN,'ef',NaN,'kappa',0,'D',1,'d',0);

    case 'trial'

        old=varargin{1};
        e=varargin{2};
        e=e(:);

        p=old;

        assert(numel(e)==6 && all(isfinite(e)), ...
            'Invalid local strain.');

        shear=[6 5;
               6 4;
               5 4];

        % ================================================
        % DAMAGE INITIATION
        % ================================================

        if p.plane==0

            s=p.C*e;
            F=zeros(3,1);

            for i=1:3

                F(i)=(max(s(i),0)/p.Xm)^2 + ...
                    sum((s(shear(i,:))/p.Ym).^2);

            end

            [Fmax,i]=max(F);

            if Fmax<1
                return;
            end

            j=shear(i,:);

            n=max(e(i),0);
            t=norm(e(j));
            q=hypot(n,t);

            assert(q>0, ...
                'Stress initiation without positive driving strain.');

            cn=n/q;
            cs=t/q;

            % Mixed-mode initiation strain

            p.e0=1/sqrt( ...
                (p.E*cn/p.Xm)^2 + ...
                (p.G*cs/p.Ym)^2);

            % Mixed-mode final strain

            p.ef=2/(p.lc*p.e0*( ...
                p.E*cn^2/p.GIC + ...
                p.G*cs^2/p.GIIC));

            assert(isfinite(p.ef) && p.ef>p.e0, ...
                'Snapback: reduce lc or check fracture inputs.');

            p.plane=i;
            p.shears=j;

        end

        % ================================================
        % DAMAGE EVOLUTION
        % ================================================

        q=hypot(max(e(p.plane),0), ...
                norm(e(p.shears)));

        p.kappa=max(old.kappa,q);

        if p.kappa<=p.e0

            D=1;

        elseif p.kappa>=p.ef

            D=p.floor;

        else

            D=p.e0*(p.ef-p.kappa)/ ...
                (p.kappa*(p.ef-p.e0));

        end

        % Irreversible damage

        p.D=max(p.floor,min(old.D,D));

        p.d=1-p.D;

        % ================================================
        % DIRECTIONAL STIFFNESS DEGRADATION
        % ================================================

        S=p.S0;

        for i=[p.plane p.shears]

            S(i,i)=S(i,i)/p.D;

        end

        p.C=S\eye(6);

        p.C=(p.C+p.C')/2;

    otherwise

        error('Unknown MatrixCrackBand action: %s',action);

end

end

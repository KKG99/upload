function Out = Run_All_Weave_Elastic_Benchmarks()
% RUN_ALL_WEAVE_ELASTIC_BENCHMARKS
% Source-based comparison of A1 GMC tow + 2-step weave against published
% plain-weave results. NO damage, NO fitting, NO changes to project code.
%
% Put in A1 root alongside WeaveProps/ and Functions/, then run:
%   Out = Run_All_Weave_Elastic_Benchmarks;
%
% INPUT UNITS: GPa for all elastic moduli; mm for geometry; degrees for phi.
% Reference publications do not necessarily use GMC or the RUC401 shape.
% Errors below are therefore cross-method COMPARISONS, not automatically
% numerical VERIFICATION. NASA 2003 is the same-method verification.
%
% The 2012, 2019 and 2023 references are deliberately listed but NOT used
% for numerical validation when the matched necessary inputs/outputs
% cannot be established from the source without assumptions.
%
% MATLAB execution is required; the authoring environment did not have
% MATLAB or GNU Octave. No calculated GMC values are pre-populated.

root = fileparts(mfilename('fullpath'));
addpath(root);
addpath(fullfile(root,'WeaveProps'));
addpath(fullfile(root,'Functions','Micromechanics'));
addpath(fullfile(root,'Functions','Utilities'));

need = {'RunWeave','GetRUC','GMC','RunMicro','GetCFromProps', ...
        'GetEffPropsFromC','EnforceTowTI','WeaveHomog','GMCaniso','WeaveFields'};
for k = 1:numel(need)
    assert(exist(need{k},'file') == 2, ...
        'Missing %s.m. Put this script in your A1 ROOT folder.',need{k});
end
fprintf('\n===== GMC -> TWO-STEP WEAVE: SOURCE-BASED BENCHMARK SUITE =====\n');
fprintf('RunWeave:   %s\n',which('RunWeave'));
fprintf('GetRUC:     %s\n',which('GetRUC'));
fprintf('GMC:        %s\n',which('GMC'));
fprintf('WeaveHomog: %s\n',which('WeaveHomog'));
fprintf('All calculated moduli below are GPa.\n');

cases = MakeCases();
for iCase=1:numel(cases)
    CheckPaperConsistency(cases(iCase));
end
rows = cell(0,12);
runNotes = cell(0,6);
raw = struct('name',{},'geometry',{},'towRUC',{},'mode',{}, ...
             'Tow',{},'Weave',{},'RUC',{});

for q = 1:numel(cases)
    c = cases(q);
    for geomNo = 1:numel(c.geometries)
        geomSpec = c.geometries(geomNo);
        if strcmp(c.key,'TR50S2020')
            ids = [2 7];  % square packing best approximated by 2; sensitivity with 7
        else
            ids = 7;
        end
        for id = ids
            % Both constituent-to-tow GMC and, if published tow full
            % engineering constants are available, independent direct-tow.
            modes = {'two_scale_GMC'};
            if c.hasFullTow
                modes{end+1} = 'published_direct_tow'; %#ok<AGROW>
            end
            for mm = 1:numel(modes)
                mode = modes{mm};
                trial = sprintf('%s | %s | towRUC=%d | %s', ...
                    c.key,geomSpec.label,id,mode);
                fprintf('\n--- %s ---\n',trial);
                try
                    if strcmp(mode,'published_direct_tow')
                        TP = c.refTow;
                        TP.Vf = c.Vf;
                        Tlocal = [];
                    else
                        % Run NASA's actual tow GMC directly from source
                        % constituent data, WITHOUT editing GetConstitProps.
                        [Tlocal,~] = CalcTowGMC(c,id);
                        TP = struct('Cstar',Tlocal.Cstar,'Vf',c.Vf);
                    end
                    Wp = struct();
                    Wp.RUCid = 401;
                    Wp.Theory = 'GMC';
                    Wp.UseDirectTow = true;
                    Wp.UseDirectMatrix = true;
                    Wp.UseCustomGeom = true;
                    Wp.TowProps = TP;
                    Wp.MatrixProps = struct('E',c.Em,'v',c.num);
                    Wp.Geom = geomSpec.geom;
                    Wp.Figures = false;
                    Wp.epsw = [0;1;0;0;0;0];
                    [W,T,~,~,~,~,RUC] = RunWeave(Wp);
                    ValidateC(W.Cstar,[trial ' weave']);
                    ValidateC(T.Cstar,[trial ' tow']);
                    % Verify exact full geometry-based volume fraction.
                    assert(abs(W.Vf - W.towVolFrac*c.Vf) < 1e-10, ...
                           'Weave.Vf inconsistent with geometry and tow Vf');
                    assert(numel(RUC.d)==4 && numel(RUC.h)==4 && numel(RUC.l)==4, ...
                           'Expected RUC401 to be 4x4x4');
                    idx = numel(raw)+1;
                    raw(idx).name = c.key;
                    raw(idx).geometry = geomSpec.label;
                    raw(idx).towRUC = id;
                    raw(idx).mode = mode;
                    raw(idx).Tow = T;
                    raw(idx).Weave = W;
                    raw(idx).RUC = RUC;
                    group = sprintf('%s_%s_RUC%d',c.key,mode,id);
                    % Tow validation is independent of weave geometry:
                    if ~isempty(fieldnames(c.refTow))
                        rows = CompareNamed(rows,c.key,group,geomSpec.label,'tow',T,c.refTow,c.towRefType,W.Vf,c.VfOverall);
                    end
                    % Paper axes: paper x/y in-plane => code 2/3; paper z out-of-plane => code 1.
                    if ~isempty(fieldnames(c.refWeave))
                        wc = WeaveForComparison(W);
                        rows = CompareNamed(rows,c.key,group,geomSpec.label,'weave',wc,c.refWeave,c.weaveRefType,W.Vf,c.VfOverall);
                    end
                    if ~isnan(c.VfOverall)
                        rref = struct('overallVf',c.VfOverall);
                        rcal = struct('overallVf',W.Vf);
                        rows = CompareNamed(rows,c.key,group,geomSpec.label,'geometry',rcal,rref, ...
                                            'volume_fraction',W.Vf,c.VfOverall);
                    end
                    fprintf('Effective volume fraction: %.6f (reported %.4f)\n', ...
                        W.Vf,c.VfOverall);
                    fprintf('Warp E=%.4f  in-plane G=%.4f  nu=%.5f\n', ...
                        W.E2,W.G23,W.v23);
                    runNotes(end+1,:) = {string(trial),"RUN",string(geomSpec.note), ...
                        W.Vf,W.E2,W.G23}; %#ok<AGROW>
                catch ME
                    fprintf(2,'ERROR for %s: %s\n',trial,ME.message);
                    runNotes(end+1,:) = {string(trial),"ERROR",string(ME.message), ...
                        NaN,NaN,NaN}; %#ok<AGROW>
                end
            end
        end
    end
end

% A published same-method GMC 2-step validation is bundled separately.
% It is invoked here so that it forms part of the single Run All command.
NASA2003 = [];
if exist('Verify_Tanov_TwoStep_DirectTow','file') == 2
    try
        fprintf('\n===== NASA AIAA 2003: SAME-METHOD 4-CASE BENCHMARK =====\n');
        NASA2003 = Verify_Tanov_TwoStep_DirectTow();
        for k = 1:numel(NASA2003)
            nm = sprintf('NASA2003_%d',k);
            rep = NASA2003(k);
            % published arrays ordered E2 E3 E1 G12 G13 G23 nu21 nu31 nu23
            props = {'E2','E3','E1','G12','G13','G23','nu21','nu31','nu23'};
            for j=1:numel(props)
                rows(end+1,:) = {string(nm),"NASA2003_directTow", ...
                    "published_geometry", "weave",string(props{j}), ...
                    rep.computed(j),rep.reference(j),rep.percentError(j), ...
                    string('NASA_2003_two_step_GMC'),rep.overallVf,NaN,true}; %#ok<AGROW>
            end
        end
        runNotes(end+1,:) = {"NASA2003_four_cases","RUN", ...
            "Published tow stiffness, geometry and two-step GMC reference",NaN,NaN,NaN};
    catch ME
        fprintf(2,'NASA2003 diagnostic failed: %s\n',ME.message);
        runNotes(end+1,:) = {"NASA2003_four_cases","ERROR",string(ME.message),NaN,NaN,NaN};
    end
else
    runNotes(end+1,:) = {"NASA2003_four_cases","SKIP", ...
        "Add Verify_Tanov_TwoStep_DirectTow.m to A1 root",NaN,NaN,NaN};
end

% Do NOT manufacture missing fiber/matrix cards or equate dataset means
% with the response of a particular weave cell.
runNotes(end+1,:) = {"Adumitroaie_Barbero_2012_five_geometries","SKIP", ...
    "Constituent elastic cards are cited to other references, not uniquely given for these five cases; warp and fill differ",NaN,NaN,NaN};
runNotes(end+1,:) = {"Hoewer_2019_CFRP","SKIP", ...
    "Matching full constituent/tow and simple RUC401 geometry set not verified",NaN,NaN,NaN};
runNotes(end+1,:) = {"Hayat_2023","SKIP", ...
    "Paper omits directly matched FE/test results; dataset means are NOT a single-case benchmark; reported tow thickness exceeds RUC thickness",NaN,NaN,NaN};

varNames = {'Study','Run','Geometry','Scale','Property','GMC','Published', ...
            'ErrorPct','ReferenceKind','ModelOverallVf','PaperOverallVf','Comparable'};
if isempty(rows)
    ResultTable = cell2table(cell(0,12),'VariableNames',varNames);
else
    % Rows use 12 fields: Study Run Geometry Scale Property GMC Published
    % ErrorPct ReferenceKind ModelOverallVf PaperOverallVf Comparable.
    ResultTable = cell2table(rows,'VariableNames',varNames);
end
RunLog = cell2table(runNotes,'VariableNames', ...
    {'Run','Status','Explanation','OverallVf','WeaveEwarp','WeaveGinplane'});

outDir = fullfile(root,'WeaveBenchmarkResults');
if ~exist(outDir,'dir'), mkdir(outDir); end
writetable(ResultTable,fullfile(outDir,'ElasticComparison.csv'));
writetable(RunLog,fullfile(outDir,'RunLog.csv'));
save(fullfile(outDir,'ElasticBenchmarkResults.mat'), ...
     'ResultTable','RunLog','raw','NASA2003','cases');

% Plot: in-plane elastic modulus against published reference for each run.
sel = strcmp(ResultTable.Scale,'weave') & strcmp(ResultTable.Property,'E2');
if any(sel)
    try
        F = figure('Color','w','Visible','off');
        sub = ResultTable(sel,:);
        n=height(sub);
        x=1:n;
        plot(x,sub.Published,'ko','LineWidth',1.25,'MarkerSize',6); hold on;
        plot(x,sub.GMC,'x','LineWidth',1.5,'MarkerSize',8);
        ylabel('In-plane Young''s modulus (GPa)');
        xticks(x); xticklabels(cellstr(sub.Run)); xtickangle(45);
        legend('Published','A1 GMC','Location','best');
        grid on; title('Comparison (geometry and model differences apply)');
        set(F,'Position',[100 100 1400 680]);
        exportgraphics(F,fullfile(outDir,'YoungModulusComparison.png'),'Resolution',150);
        close(F);
    catch ME
        warning('Could not create plot: %s',ME.message);
    end
end

fprintf('\n===== BENCHMARK REPORT =====\n');
fprintf('Successful GMC runs: %d\n',sum(strcmp(RunLog.Status,'RUN')));
fprintf('Failed: %d; Skipped: %d\n', ...
    sum(strcmp(RunLog.Status,'ERROR')),sum(strcmp(RunLog.Status,'SKIP')));
fprintf('Results: %s\n',outDir);
fprintf('IMPORTANT: non-GMC references are cross-method comparisons, not solver validation.\n');
Out = struct('Comparisons',ResultTable,'Runs',RunLog, ...
             'Raw',raw,'NASA2003',NASA2003,'OutputFolder',outDir);
end

% ======================== REFERENCE DATA ========================
function cases = MakeCases()
% Explicitly sourced tables. All reference properties in GPa.
% Geometry 'effective tow width' is a RECTANGULAR RUC401 approximation,
% never claimed as the measured lenticular tow width.

% 2020 Applied Sciences 10,6542 Tables 1,2,7,9.
c = struct();
c.key = 'TR50S2020';
c.title = '2020 TR50S/epoxy plain weave';
c.fiber = Iso(240,0.285); c.Em=2.45; c.num=0.35;
c.Vf=0.60; c.VfOverall=NaN;
c.refTow = struct('E1',144.75,'E2',13.19,'E3',13.19, ...
    'G12',3.75,'G13',3.75,'G23',2.51, ...
    'v12',0.306,'v13',0.306,'v23',0.252);
c.hasFullTow = true;
c.towRefType = '2020_T2_deterministic_FE_tow';
% Table 9 (60%) are distribution means, not deterministic one-cell FEM.
c.refWeave = struct('E2',26.70,'E3',26.70,'E1',7.04, ...
                    'G23',2.35,'G12',1.72,'G13',1.72, ...
                    'v23',0.082,'nu21',0.364,'nu31',0.364);
c.weaveRefType = '2020_T9_1000sample_mean_NOT_deterministic';
L=.900; w=.376; H=.225; TL=.990;
c.geometries = struct('label','measured_width_length_proxy', ...
    'geom',struct('a',w,'g',L/2-w,'H',H,'phi',acosd(L/TL)), ...
    'note','TW, RUC L, H measured/tabulated; phi=acos(L/TL) derived straight-path equivalent; tow thickness TT=0.093 differs from RUC401 layers');
c.geometries(2) = struct('label','measured_width_auto401', ...
    'geom',struct('a',w,'g',L/2-w,'H',H), ...
    'note','Published tow width/pitch/thickness; angle from RUC401 default atan(H/2g), NOT published');
cases(1)=c;

% 2021 Materials 14, 4393 Tables 2,5,7,8.
c = struct(); c.key='Zhou2021';
c.title='2021 T300/Cycom970 plain weave';
c.fiber=Ortho(230,13.8,0.20,0.25,8.97,4.38);
c.Em=3.35; c.num=0.35; c.Vf=0.78; c.VfOverall=0.48;
c.refTow = struct('E1',174.67,'E2',9.51,'E3',9.51, ...
    'G12',8.52,'G13',8.52,'G23',3.39, ...
    'v12',0.28,'v13',0.28,'v23',0.41);
c.hasFullTow=true;
c.towRefType='2021_T8_FE_tow';
c.refWeave=struct('E2',56.85,'E3',56.85,'G23',3.86,'v23',0.042);
c.weaveRefType='2021_T5_tested_fabric_properties';
L=3.754; w=1.775; H=.216; R=8.832; Vtow=.61;
c.geometries = [ ...
    struct('label','measured_width_arc_proxy', ...
     'geom',struct('a',w,'g',L/2-w,'H',H,'phi',asind((L/4)/R)), ...
     'note','Measured physical width, pitch, H; circular-arc tangent proxy, does not preserve tow volume fraction'), ...
    struct('label','volume_equivalent_arc_proxy', ...
     'geom',struct('a',Vtow*L/2,'g',(1-Vtow)*L/2,'H',H,'phi',asind((L/4)/R)), ...
     'note','Width/gap MODIFIED to preserve published tow fraction 0.61; NOT the measured tow width') ];
cases(end+1)=c;

% 2022 Aerospace 9, 26 Tables 1,2,4,5,6.
c = struct(); c.key='Zhou2022';
c.title='2022 T300/Cycom970 plain weave';
c.fiber=Ortho(230,13.8,0.20,0.25,8.97,4.38);
c.Em=3.35; c.num=0.35; c.Vf=0.78; c.VfOverall=0.56;
% Paper Table 5 does not report v12 or v23. Direct tow cannot be
% reproduced without inventing them; compare the published subset only.
c.refTow = struct('E1',180.24,'E2',10.27,'E3',10.27, ...
                   'G12',9.66,'G13',9.66,'G23',3.78);
c.hasFullTow=false;
c.towRefType='2022_T5_analytical_Chamis_tow';
c.refWeave=struct('E2',56.85,'E3',56.85);
c.weaveRefType='2022_T6_experimental_mean_56_85';
L=4.0; w=1.82; H=3.456/16; R=7.18; Vtow=.72;
c.geometries = [ ...
    struct('label','measured_width_arc_proxy', ...
      'geom',struct('a',w,'g',L/2-w,'H',H,'phi',asind((L/4)/R)), ...
      'note','Measured tow width, pitch, radius; H = 16-ply specimen thickness / 16, not separately stated weave RUC height'), ...
    struct('label','volume_equivalent_arc_proxy', ...
      'geom',struct('a',Vtow*L/2,'g',(1-Vtow)*L/2,'H',H,'phi',asind((L/4)/R)), ...
      'note','Equivalent width/gap to preserve published tow fraction 0.72; H inferred from 16-ply specimen') ];
cases(end+1)=c;
end

function CheckPaperConsistency(c)
% Print reference-data consistency warnings without modifying the source.
if isfield(c.fiber,'G12')
    Gf = c.fiber.G12;
else
    Gf = c.fiber.GL;
end
Gm = c.Em/(2*(1+c.num));
GVoigt = c.Vf*Gf + (1-c.Vf)*Gm;
if isfield(c.refTow,'G12') && c.refTow.G12 > GVoigt*(1+1e-6)
    fprintf(2,['SOURCE WARNING %s: published tow G12=%.4f GPa exceeds ', ...
        'constituent Voigt upper bound=%.4f GPa. ', ...
        'DO NOT treat this property as an exact pass/fail solver target.\n'], ...
        c.key,c.refTow.G12,GVoigt);
end
if isfield(c.refTow,'v23') && isfield(c.refTow,'E2') && isfield(c.refTow,'G23')
    tiG23 = c.refTow.E2/(2*(1+c.refTow.v23));
    if abs(tiG23-c.refTow.G23)/max(abs(tiG23),eps) > 0.05
       fprintf(2,['SOURCE WARNING %s: published tow G23=%.4f GPa ', ...
           'does not satisfy transverse-isotropy relation ', ...
           'E2/[2(1+nu23)]=%.4f GPa. Published values are ', ...
           'kept as printed in direct-tow mode.\n'], ...
           c.key,c.refTow.G23,tiG23);
    end
end
end

function P = Iso(E,nu)
P=struct('EL',E,'ET',E,'vL',nu,'vT',nu,'GL',E/(2*(1+nu)));
end

function P = Ortho(EL,ET,nu12,nu23,GL,G23)
P=struct('E1',EL,'E2',ET,'E3',ET, ...
    'v12',nu12,'v13',nu12,'v23',nu23, ...
    'G12',GL,'G13',GL,'G23',G23);
end

function [T,C] = CalcTowGMC(caseData,rucID)
Constits=struct();
Constits.Fiber=caseData.fiber;
Constits.Matrix=Iso(caseData.Em,caseData.num);
Constits.Fiber.constID=1;
Constits.Matrix.constID=2;
Constits.Fiber.aL=0; Constits.Fiber.aT=0;
Constits.Matrix.aL=0; Constits.Matrix.aT=0;
Constits.Fiber.name='paper fiber';
Constits.Matrix.name='paper matrix';
ValidateC(GetCFromProps(Constits.Fiber),[caseData.key ' fiber']);
ValidateC(GetCFromProps(Constits.Matrix),[caseData.key ' matrix']);
Vol=struct('Vf',caseData.Vf,'Vi',0);
T=struct('used',true);
T=RunMicro('GMC','Tow',Vol,Constits,T,rucID);
[T,C,~]=EnforceTowTI(T);
ValidateC(C,[caseData.key ' homogenized tow']);
end

function W = WeaveForComparison(X)
W = X;
S = X.Cstar\eye(6);
% nu21 is lateral thickness strain caused by warp-directed stress.
W.nu21 = -S(1,2)/S(2,2);
W.nu31 = -S(1,3)/S(3,3);
W.overallVf = X.Vf;
end

function Verify = ValidateC(C,label)
S=0.5*(C+C.');
e=eig(S);
if any(~isfinite(C(:))) || min(e)<=0
    error('Nonpositive/invalid stiffness: %s (min eigenvalue=%.3g)',label,min(e));
end
if norm(C-C.','fro')/max(norm(C,'fro'),eps) > 1e-6
    error('Stiffness tensor not symmetric: %s',label);
end
Verify = true;
end

function rows = CompareNamed(rows,study,run,geometry,scale,pred,ref,kind,Vf,VfPaper)
names=fieldnames(ref);
for kk=1:numel(names)
    fn=names{kk};
    if ~isfield(pred,fn), continue; end
    p=pred.(fn); r=ref.(fn);
    if ~isfinite(r) || ~isfinite(p), continue; end
    err=100*(p-r)/max(abs(r),1e-14);
    fprintf('%-14s  A1 GMC %12.5f   paper %12.5f   error %+9.3f%%\n', ...
        fn,p,r,err);
    rows(end+1,:)={string(study),string(run),string(geometry), ...
        string(scale),string(fn),p,r,err,string(kind),Vf,VfPaper,true}; %#ok<AGROW>
end
end

% =========================================================================
% RunVfSweep.m — Generate monotonic SimWeaveDamage curves varying ONLY Vf
% =========================================================================
% HOW TO USE:
%   1. Edit WeaveProblemDef.m as usual (set NINC, epswMax, Nf, Nm, RUCid,
%      towRUCid, DamageFactor, BAA options, etc.).
%      TIP: For smooth curves, set Wp.NINC = 100 (or 50) in WeaveProblemDef.m,
%           and use Wp.towRUCid = 7 if you want Vf up to 0.80 (towRUCid = 27
%           has a geometric limit Vf_max = 0.7988).
%   2. Set the 4 options below and press Run (F5).
% =========================================================================

clear; clc;

% ---- Simple Sweep Settings (edit these 4 lines if needed) ----
numCurves = 10;       % number of SimWeaveDamage curves
vfMin     = 0.35;      % starting tow fibre volume fraction Vf
vfMax     = 0.80;      % ending tow fibre volume fraction Vf
outFile   = fullfile('..', 'Surrogate', 'data', 'weave_vf_sweep.mat');

% ---- Setup Paths & Base Settings from WeaveProblemDef ----
hereDir = fileparts(mfilename('fullpath'));
a1Dir   = fileparts(hereDir);
addpath(a1Dir, fullfile(a1Dir,'Functions','Utilities'), fullfile(a1Dir,'Functions','WriteResults'), ...
        fullfile(a1Dir,'Functions','Micromechanics'), fullfile(a1Dir,'Functions','Margins'), ...
        fullfile(a1Dir,'Functions','Damage'), hereDir);

WpBase = WeaveProblemDef();
WpBase.Figures = false;   % do not pop up 100 figure windows during the sweep

if WpBase.NINC < 10
    warning(['Wp.NINC in WeaveProblemDef.m is currently %d. ' ...
             'Consider setting Wp.NINC = 50 or 100 for smooth surrogate curves.'], WpBase.NINC);
end

% ---- Check geometric Vf_max limit for your chosen towRUCid ----
[cp] = GetConstitProps();
Constits.Fiber  = cp{WpBase.Nf};
Constits.Matrix = cp{WpBase.Nm};
rucProbe = GetRUC(Constits, min(0.5, vfMin), WpBase.Vi, WpBase.towRUCid);
vfLimit  = rucProbe.Vf_max - WpBase.Vi - 0.002;
if vfMax > vfLimit
    fprintf(['Note: towRUCid = %d has physical Vf_max = %.4f (with Vi = %.3f). ' ...
             'Clamping vfMax from %.3f to %.4f.\n'], ...
             WpBase.towRUCid, rucProbe.Vf_max, WpBase.Vi, vfMax, vfLimit);
    vfMax = vfLimit;
end

vfList = linspace(vfMin, vfMax, numCurves);
nPts   = WpBase.NINC + 1;

eps        = zeros(numCurves, nPts, 6);
sig        = zeros(numCurves, nPts, 6);
ndam       = zeros(numCurves, nPts);
nsub       = zeros(numCurves, nPts);
params     = zeros(numCurves, 2);
paramNames = {'Vf', 'VfWeave'};

[~, loadAxis] = max(abs(WpBase.epswMax));
if isempty(loadAxis) || max(abs(WpBase.epswMax)) == 0, loadAxis = 2; end

fprintf('Running %d monotonic SimWeaveDamage curves (Vf = %.3f to %.3f, NINC = %d)...\n', ...
    numCurves, vfMin, vfMax, WpBase.NINC);

tStart = tic;
for c = 1:numCurves
    Wp = WpBase;
    Wp.Vf = vfList(c);

    [Hist, Weave] = SimWeaveDamage(Wp);

    eps(c, :, :) = Hist.eps;
    sig(c, :, :) = Hist.sig;
    ndam(c, :)   = Hist.ndam(:).';
    nsub(c, :)   = Hist.nsub(:).';
    vfW = Wp.Vf * 0.5;
    if isfield(Weave, 'Vf') && ~isempty(Weave.Vf), vfW = Weave.Vf; end
    params(c, :) = [Wp.Vf, vfW];

    fprintf('>>> Curve %3d / %3d finished (Vf = %.4f, peak sig = %.2f MPa) [%.1fs]\n', ...
        c, numCurves, Wp.Vf, max(abs(Hist.sig(:, loadAxis))), toc(tStart));
end

% ---- Save .mat (-v7) and .csv for Python ----
outDir = fileparts(outFile);
if ~isempty(outDir) && ~exist(outDir, 'dir'), mkdir(outDir); end

meta.units   = 'MPa';
meta.numCurves = numCurves;
meta.nPts    = nPts;
meta.Theory  = char(WpBase.Theory);
meta.RUCid   = WpBase.RUCid;
meta.towRUCid = WpBase.towRUCid;
meta.loadAxis = loadAxis;

save(outFile, 'eps', 'sig', 'ndam', 'nsub', 'params', 'paramNames', 'vfList', 'meta', '-v7');

[pDir, pName, ~] = fileparts(outFile);
csvFile = fullfile(pDir, [pName '.csv']);
fid = fopen(csvFile, 'w');
fprintf(fid, 'case_id,step,Vf,eps11,eps22,eps33,eps23,eps13,eps12,sig11,sig22,sig33,sig23,sig13,sig12,ndam,nsub\n');
for c = 1:numCurves
    for t = 1:nPts
        fprintf(fid, '%d,%d,%.6f,%.8e,%.8e,%.8e,%.8e,%.8e,%.8e,%.8e,%.8e,%.8e,%.8e,%.8e,%.8e,%d,%d\n', ...
            c-1, t-1, params(c,1), ...
            eps(c,t,1), eps(c,t,2), eps(c,t,3), eps(c,t,4), eps(c,t,5), eps(c,t,6), ...
            sig(c,t,1), sig(c,t,2), sig(c,t,3), sig(c,t,4), sig(c,t,5), sig(c,t,6), ...
            round(ndam(c,t)), round(nsub(c,t)));
    end
end
fclose(fid);

fprintf('\nSaved %d curves to:\n  MAT: %s\n  CSV: %s\n', numCurves, outFile, csvFile);

% ---- Summary plot of all curves ----
figure('Name', 'SimWeaveDamage Vf Sweep');
hold on; grid on;
for c = 1:numCurves
    plot(eps(c, :, loadAxis), sig(c, :, loadAxis), '-', 'LineWidth', 1.0);
end
xlabel(['\epsilon_{' num2str(loadAxis) '}']);
ylabel(['\sigma_{' num2str(loadAxis) '} [MPa]']);
title(sprintf('%d SimWeaveDamage Curves (V_f = %.2f to %.2f)', numCurves, vfMin, vfMax));

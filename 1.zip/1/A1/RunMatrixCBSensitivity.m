
function results=RunMatrixCBSensitivity(Wp,lcValues_mm,orientations)
% Run predictive strain-controlled laminates for independently specified lc.
% No curve fitting or automatic choice of the best lc.
% Example (after supplying matrix properties in WeaveProblemDef):
%   Wp=WeaveProblemDef();
%   results=RunMatrixCBSensitivity(Wp,myLengths,[0 90 0 90;45 -45 45 -45]);
% myLengths must be independently justified, in mm.

if nargin<1 || isempty(Wp), Wp=WeaveProblemDef(); end

if nargin<2 || isempty(lcValues_mm) || ~isnumeric(lcValues_mm) || ...
        any(~isfinite(lcValues_mm(:))) || any(lcValues_mm(:)<=0)

    error('Supply positive, independently justified lcValues_mm.');

end

if nargin<3 || isempty(orientations)
    orientations=Wp.Orient(:).';
end

if size(orientations,2)~=numel(Wp.tply)

    error('Every layup must match the number of ply thicknesses in Wp.tply.');

end

Wp.StrainControl=true;
Wp.Figures=false;

results=cell(size(orientations,1),numel(lcValues_mm));

for i=1:size(orientations,1)

    Wp.Orient=orientations(i,:);

    figure('Name',sprintf('Matrix CB sensitivity: layup %d',i));

    hold on;

    for j=1:numel(lcValues_mm)

        Wp.MatrixCB.lc_mm=lcValues_mm(j);

        [H,~,~,~]=WeaveLamSimDamage(Wp);

        results{i,j}=struct( ...
            'lc_mm',lcValues_mm(j), ...
            'Orient',Wp.Orient, ...
            'strain',[0;H.ex(:)], ...
            'stress_MPa',[0;H.Nx(:)/sum(Wp.tply)], ...
            'Hist',H);

        plot(results{i,j}.strain,results{i,j}.stress_MPa, ...
            'DisplayName',sprintf('lc = %.5g mm',lcValues_mm(j)));

    end

    xlabel('Axial strain');
    ylabel('Average tensile stress (MPa)');

    title(sprintf('Layup [%s]',num2str(Wp.Orient)));

    legend('Location','best');
    grid on;

end

end

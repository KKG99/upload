function [Tow, Cti, aTI] = EnforceTowTI(Tow)
% +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% Purpose: Enforce transverse isotropy (about tow fibre axis 1) on the
%          homogenized tow stiffness Cstar and CTE via Aboudi / Bednarcyk
%          circumferential averaging in the x2-x3 plane (same stiffness
%          projection as NASA MOC.m).
%          Voigt order: [11 22 33 23 13 12], engineering shear strains.
% Input:
% - Tow: struct returned by RunMicro (requires Cstar, a1..a3)
% Output:
% - Tow: updated struct with transversely isotropic Cstar, engineering
%        constants (E1..G23), and CTEs (a1..a3)
% - Cti: 6x6 transversely isotropic stiffness matrix
% - aTI: 6x1 transversely isotropic CTE vector
% +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

C0 = 0.5 * (Tow.Cstar + Tow.Cstar.');

Cti = zeros(6);
Cti(1,1) = C0(1,1);
Cti(1,2) = 0.5 * (C0(1,2) + C0(1,3));
Cti(2,1) = Cti(1,2);
Cti(1,3) = Cti(1,2);
Cti(3,1) = Cti(1,2);
Cti(2,2) = 3.0 * (C0(2,2) + C0(3,3)) / 8.0 + C0(2,3) / 4.0 + C0(4,4) / 2.0;
Cti(3,3) = Cti(2,2);
Cti(2,3) = (C0(2,2) + C0(3,3)) / 8.0 + 3.0 * C0(2,3) / 4.0 - C0(4,4) / 2.0;
Cti(3,2) = Cti(2,3);
Cti(4,4) = 0.5 * (Cti(2,2) - Cti(2,3));
Cti(5,5) = 0.5 * (C0(5,5) + C0(6,6));
Cti(6,6) = Cti(5,5);

a0 = [Tow.a1; Tow.a2; Tow.a3; 0; 0; 0];
gam0  = C0 * a0;
gamTI = [gam0(1); 0.5 * (gam0(2) + gam0(3)); 0.5 * (gam0(2) + gam0(3)); 0; 0; 0];
aTI   = Cti \ gamTI;

Tow.Cstar = Cti;
Eff = GetEffPropsFromC(Cti);
Tow.E1  = Eff.E1;   Tow.E2  = Eff.E2;   Tow.E3  = Eff.E3;
Tow.v12 = Eff.v12;  Tow.v13 = Eff.v13;  Tow.v23 = Eff.v23;
Tow.G12 = Eff.G12;  Tow.G13 = Eff.G13;  Tow.G23 = Eff.G23;
Tow.a1  = aTI(1);   Tow.a2  = aTI(2);   Tow.a3  = aTI(3);

end

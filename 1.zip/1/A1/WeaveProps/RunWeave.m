
function [Weave, Tow, Sb, Eb, Sc, Ec, wruc] = RunWeave(Wp)
% +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% Purpose: Effective properties of a woven ply.
%          Scale 1 (fibre+matrix -> tow) with NASA's RunMicro, OR directly
%          from user-supplied tow/matrix properties (for paper verification).
%          Scale 2 (tow -> weave) with THICKNESS-FIRST two-step GMC of WeaveHomog.
% Input (struct Wp):
% - Wp.RUCid    : weave RUC id        (401 plain, 402 twill, 403 8HS)
%   Standard constituent mode (Wp.UseDirectTow = false or omitted without TowProps):
% - Wp.Theory   : 'GMC' or 'HFGMC'   (applies at the tow scale)
% - Wp.towRUCid : tow RUC id          (e.g. 26, 27, 7)
% - Wp.Vf, Wp.Vi: tow fibre / interface volume fractions
% - Wp.Nf, Wp.Nm: fibre and matrix material numbers in GetConstitProps
%   Direct tow / paper verification mode:
% - Wp.UseDirectTow : true to bypass RunMicro and use Wp.TowProps directly
% - Wp.TowProps     : struct with tow properties in tow axes (axis 1 = fibre):
%                     * 6x6 stiffness: Cstar or C
%                     * 9 orthotropic: E1,E2,E3,v12,v13,v23,G23,G13,G12
%                     * Transversely isotropic (any alias set):
%                       EL/EA/E1, ET/E2, vL/vA/v12, GL/GA/G12, and vT/v23 or GT/G23
%                     * Optional CTE: aL/aA, aT (or a1, a2, a3), default 0
%                     * Optional tow Vf (used only to report overall Weave.Vf)
% - Wp.MatrixProps  : optional struct overriding Wp.Nm for matrix pockets:
%                     * Isotropic: E (or Em) and v (or nu) [or E and G]
%                     * Or TI/orthotropic/Cstar in same format as TowProps
%                     * Optional CTE: a (or am, or aL, aT), default 0
% - Wp.Geom         : optional struct overriding weave geometry in GetRUC:
%                     * w (or a), g, t (or H = 4*t), optional phi [deg]
% Optional:
% - Wp.epsw : 6x1 macro strain in Bednarcyk weave axes [x1=thk, x2=warp, x3=weft]
%             (default: unit strain along x2 warp)
% - Wp.Figures : true to draw the weave stress plots
% - Wp.TitleStr: title string for those plots
% - Wp.Units   : optional unit label for printout (e.g. 'MPa' or 'GPa')
% Output:
% - Weave: struct with RUCid, Vf (overall fibre fraction), Cstar, Ccol, CTE
%          and the 12 engineering constants in weave axes
% - Tow:   struct with the same constants in tow axes, plus direct/RUC info
% - Sb{k,b,g}, Eb{k,b,g}: block stress and strain, 6x1, weave axes
% - Sc{b,g}, Ec{b,g}:     thickness-averaged block stress and strain
% - wruc:  the weave RUC struct
% +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

if ~isfield(Wp, 'RUCid') || isempty(Wp.RUCid)
    error('RunWeave: Wp.RUCid is required');
end

if isfield(Wp, 'UseDirectTow')
    useDirectTow = logical(Wp.UseDirectTow);
else
    useDirectTow = isfield(Wp, 'TowProps') && ~isempty(Wp.TowProps);
end

if isfield(Wp, 'UseDirectMatrix')
    useDirectMatrix = logical(Wp.UseDirectMatrix);
else
    useDirectMatrix = (useDirectTow || ~isfield(Wp, 'UseDirectTow')) && ...
                      isfield(Wp, 'MatrixProps') && ~isempty(Wp.MatrixProps);
end

if isfield(Wp, 'UseCustomGeom')
    useCustomGeom = logical(Wp.UseCustomGeom);
else
    useCustomGeom = (useDirectTow || ~isfield(Wp, 'UseDirectTow')) && ...
                    isfield(Wp, 'Geom') && ~isempty(Wp.Geom);
end

if useDirectTow
    if ~isfield(Wp, 'TowProps') || ~isstruct(Wp.TowProps)
        error('RunWeave: Wp.TowProps struct is required when UseDirectTow is true');
    end
else
    if ~isfield(Wp,'Theory') || ~ismember(Wp.Theory, {'GMC','HFGMC'})
        error('WeaveAnalysis: Wp.Theory must be ''GMC'' or ''HFGMC''');
    end
    for f = {'towRUCid','Vf','Vi','Nf'}
        if ~isfield(Wp, f{1})
            error(['WeaveAnalysis: Wp.' f{1} ' is required']);
        end
    end
end

if useDirectMatrix
    if ~isfield(Wp, 'MatrixProps') || ~isstruct(Wp.MatrixProps)
        error('RunWeave: Wp.MatrixProps struct is required when UseDirectMatrix is true');
    end
elseif ~isfield(Wp, 'Nm') || isempty(Wp.Nm)
    error('WeaveAnalysis: Wp.Nm (or Wp.MatrixProps) is required');
end

%-----------------------------------------------------------------
% 1) Constituents (from GetConstitProps unless overridden directly)
%-----------------------------------------------------------------
if ~useDirectTow || ~useDirectMatrix
    [constitprops] = GetConstitProps;
end

if useDirectTow
    Constits.Fiber = struct('constID', 1, 'name', "Direct Tow");
else
    Constits.Fiber = constitprops{Wp.Nf};
end

if useDirectMatrix
    [Constits.Matrix, Cmat, amat] = BuildDirectMatrix(Wp.MatrixProps);
else
    Constits.Matrix = constitprops{Wp.Nm};
    Cmat = GetCFromProps(Constits.Matrix);
    amat = [Constits.Matrix.aL; Constits.Matrix.aT; Constits.Matrix.aT; 0; 0; 0];
end

%-----------------------------------------------------------------
% 2) Scale 1 : fibre + matrix -> tow, OR direct tow properties
%-----------------------------------------------------------------
if useDirectTow
    [Tow, Ctow, atow] = BuildDirectTow(Wp.TowProps);
else
    Vol.Vf = Wp.Vf;
    Vol.Vi = Wp.Vi;
    Tow.used = true;
    Tow.direct = false;
    Tow = RunMicro(Wp.Theory, 'Tow', Vol, Constits, Tow, Wp.towRUCid);

    if ~isfield(Wp, 'EnforceTowTI') || logical(Wp.EnforceTowTI)
        [Tow, Ctow, atow] = EnforceTowTI(Tow);
    else
        Ctow = Tow.Cstar;
        atow = [Tow.a1; Tow.a2; Tow.a3; 0; 0; 0];
    end
end

%-----------------------------------------------------------------
% 3) Weave RUC
%-----------------------------------------------------------------
if useDirectTow
    if ~isnan(Tow.Vf) && Tow.Vf > 0
        rucVf = Tow.Vf;
    else
        rucVf = 0.5;
    end
    rucVi = 0;
else
    rucVf = Wp.Vf;
    rucVi = Wp.Vi;
end

geom = [];
if useCustomGeom && isfield(Wp, 'Geom') && ~isempty(Wp.Geom)
    geom = Wp.Geom;
end
[wruc] = GetRUC(Constits, rucVf, rucVi, Wp.RUCid, geom);

nx = numel(wruc.d);
ny = numel(wruc.h);
nz = numel(wruc.l);

if ~isequal(size(wruc.matsCh), [nx ny nz])
    error('WeaveAnalysis: RUC.matsCh must be %dx%dx%d', nx, ny, nz);
end

%-----------------------------------------------------------------
% 4) Blocks: tow orientation using original FOUR-input TowCfull
%    Warp: theta = 0 degrees; Weft: theta = 90 degrees
%    Signed crimp angle phi is supplied directly to TowCfull.
%-----------------------------------------------------------------
Cb = cell(nx, ny, nz);
ab = cell(nx, ny, nz);
nUp = 0;
nDown = 0;

for b = 1:nx
    for g = 1:ny
        for k = 1:nz
            ch = wruc.matsCh(b,g,k);
            phi = wruc.crimp(b,g,k);

            switch ch
                case '5'   % Warp: x2 direction
                    [Cb{b,g,k}, ab{b,g,k}] = TowCfull(Ctow, atow, 0, phi);

                case '6'   % Weft: x3 direction
                    [Cb{b,g,k}, ab{b,g,k}] = TowCfull(Ctow, atow, 90, phi);

                case 'M'   % Matrix pocket
                    Cb{b,g,k} = Cmat;
                    ab{b,g,k} = amat;

                otherwise
                    error('RunWeave: bad matsCh = %s', ch);
            end

            if ch == '5' || ch == '6'
                if phi > 0
                    nUp = nUp + 1;
                elseif phi < 0
                    nDown = nDown + 1;
                end
            end
        end
    end
end
fprintf('Tow inclination: %d upward, %d downward blocks\n', nUp, nDown);

% -- Overall fibre volume fraction, from the RUC geometry
towVol = 0;
for b = 1:nx
    for g = 1:ny
        for k = 1:nz
            if wruc.matsCh(b,g,k) ~= 'M'
                towVol = towVol + wruc.d(b)*wruc.h(g)*wruc.l(k);
            end
        end
    end
end
totalVol = sum(wruc.d)*sum(wruc.h)*sum(wruc.l);
if useDirectTow
    towVf = Tow.Vf;
else
    towVf = Wp.Vf;
    if Wp.Vf == 0
        towVf = 0;
    elseif isfield(Tow, 'RUC') && isfield(Tow.RUC, 'Vf')
        towVf = Tow.RUC.Vf;
    end
end
if isnan(towVf)
    VfWeave = NaN;
else
    VfWeave = towVf * towVol / totalVol;
end

%-----------------------------------------------------------------
% 5) Scale 2 : tow -> weave, two-step GMC, plus the block fields
%-----------------------------------------------------------------
if isfield(Wp, 'epsw')
    epsw = Wp.epsw;
else
    epsw = [0; 1; 0; 0; 0; 0];      % default: unit strain along the warp (x2)
end

[Sb, Eb, Sc, Ec, Cweave, aweave, Ccol] = ...
    WeaveFields(Cb, ab, wruc.d, wruc.h, wruc.l, epsw);

% -- Stress distribution on the weave RUC grid
if isfield(Wp, 'Figures') && Wp.Figures
    if isfield(Wp, 'TitleStr')
        PlotWeaveFields(wruc, Sc, Sb, Wp.TitleStr);
    else
        PlotWeaveFields(wruc, Sc, Sb, ['weave RUC ' num2str(Wp.RUCid)]);
    end
end

Weave.RUCid = Wp.RUCid;
Weave.Vf    = VfWeave;
Weave.towVolFrac = towVol / totalVol;
Weave.Cstar = Cweave;

% Thickness-first Step-1 homogenized columns
Weave.Ccol  = Ccol;
Weave.Cwarp = {};
Weave.HomogOrder = 'thickness-then-inplane';

Weave.CTE = aweave;
[Weave] = AddEngProps(Weave, Cweave, aweave);

if max([Weave.E1 Weave.E2 Weave.E3 Tow.E1 Tow.E2 Tow.E3]) < 1000
    fmt = '%9.4f';
else
    fmt = '%9.1f';
end

fprintf('\n            E1        E2        E3      v12      v13      v23      G12       G13       G23      CTE1     CTE2     CTE3\n');
fprintf(['tow   ' fmt ' ' fmt ' ' fmt ' %8.4f %8.4f %8.4f ' fmt ' ' fmt ' ' fmt ' %8.2e %8.2e %8.2e\n'], ...
    Tow.E1, Tow.E2, Tow.E3, Tow.v12, Tow.v13, Tow.v23, Tow.G12, Tow.G13, Tow.G23, ...
    Tow.a1, Tow.a2, Tow.a3);
fprintf(['weave ' fmt ' ' fmt ' ' fmt ' %8.4f %8.4f %8.4f ' fmt ' ' fmt ' ' fmt ' %8.2e %8.2e %8.2e\n'], ...
    Weave.E1, Weave.E2, Weave.E3, Weave.v12, Weave.v13, Weave.v23, ...
    Weave.G12, Weave.G13, Weave.G23, Weave.a1, Weave.a2, Weave.a3);
if isnan(Weave.Vf)
    fprintf('\nweave RUCid = %d   tow volume fraction = %.6f   (overall Vf = N/A)\n\n', ...
        Weave.RUCid, Weave.towVolFrac);
else
    fprintf('\nweave RUCid = %d   overall fibre Vf = %.6f   (tow Vf = %.4f)\n\n', ...
        Weave.RUCid, Weave.Vf, towVf);
end

end

%=========================================================================
function [s] = AddEngProps(s, C, a)
[E] = GetEffPropsFromC(C);
s.E1  = E.E1;   s.E2  = E.E2;   s.E3  = E.E3;
s.v12 = E.v12;  s.v13 = E.v13;  s.v23 = E.v23;
s.G12 = E.G12;  s.G13 = E.G13;  s.G23 = E.G23;
s.a1 = a(1);    s.a2 = a(2);    s.a3 = a(3);
end

%=========================================================================
function [Tow, Ctow, atow] = BuildDirectTow(TP)
[Ctow, atow] = PropsToCAndAlpha(TP, 'TowProps');
Tow.used   = true;
Tow.direct = true;
Tow.Cstar  = Ctow;
[Tow] = AddEngProps(Tow, Ctow, atow);

[vf, hasVf] = PickField(TP, {'Vf', 'vf'});
if hasVf
    Tow.Vf = vf;
else
    Tow.Vf = NaN;
end
end

%=========================================================================
function [MatProps, Cmat, amat] = BuildDirectMatrix(MP)
[Cmat, amat] = PropsToCAndAlpha(MP, 'MatrixProps');
MatProps.constID = 2;
if isfield(MP, 'name') && ~isempty(MP.name)
    MatProps.name = MP.name;
else
    MatProps.name = "Direct Matrix";
end
MatProps.aL = amat(1);
MatProps.aT = amat(2);
end

%=========================================================================
function [C, a6] = PropsToCAndAlpha(P, label)
% Convert direct stiffness, orthotropic, transversely isotropic, or
% isotropic property struct into 6x6 stiffness C and 6x1 CTE a6.

if isfield(P, 'Cstar') && ~isempty(P.Cstar)
    C = P.Cstar;
elseif isfield(P, 'C') && ~isempty(P.C)
    C = P.C;
else
    C = [];
end

if ~isempty(C)
    if ~isequal(size(C), [6 6])
        error(['RunWeave: ' label '.Cstar must be 6x6']);
    end
    C = 0.5 * (C + C.');
else
    hasOrtho = isfield(P,'E1') && isfield(P,'E2') && isfield(P,'E3') && ...
               isfield(P,'v12') && isfield(P,'v13') && isfield(P,'v23') && ...
               isfield(P,'G23') && isfield(P,'G13') && isfield(P,'G12');

    if hasOrtho
        C = GetCFromProps(P);
    else
        [Eiso, hasEiso] = PickField(P, {'E', 'Em'});
        [EL, hasEL]     = PickField(P, {'EL', 'EA', 'E1'});

        if hasEiso && ~hasEL
            [vIso, hasV] = PickField(P, {'v', 'nu', 'vm', 'vL', 'vA'});
            [gIso, hasG] = PickField(P, {'G', 'Gm', 'GL', 'GA'});

            if hasV
                GL = Eiso / (2 * (1 + vIso));
                S = struct('EL', Eiso, 'ET', Eiso, ...
                           'vL', vIso, 'vT', vIso, 'GL', GL);
            elseif hasG
                vIso = Eiso / (2 * gIso) - 1;
                S = struct('EL', Eiso, 'ET', Eiso, ...
                           'vL', vIso, 'vT', vIso, 'GL', gIso);
            else
                error(['RunWeave: isotropic ' label ...
                       ' needs E and v (or E and G)']);
            end

            C = GetCFromProps(S);
        else
            [ET, hasET] = PickField(P, {'ET', 'E2'});
            [vL, hasVL] = PickField(P, ...
                {'vL', 'vA', 'v12', 'nuL', 'nuA', 'nu12'});
            [GL, hasGL] = PickField(P, ...
                {'GL', 'GA', 'G12', 'G13'});
            [vT, hasVT] = PickField(P, ...
                {'vT', 'v23', 'nuT', 'nu23'});
            [GT, hasGT] = PickField(P, {'GT', 'G23'});

            if ~(hasEL && hasET && hasVL && hasGL && ...
                    (hasVT || hasGT))
                error(['RunWeave: ' label ...
                       ' requires EL/EA/E1, ET/E2, vL/vA/v12, ' ...
                       'GL/GA/G12, and vT/v23 or GT/G23']);
            end

            if hasVT && hasGT
                S = struct('E1', EL, 'E2', ET, 'E3', ET, ...
                           'v12', vL, 'v13', vL, 'v23', vT, ...
                           'G23', GT, 'G13', GL, 'G12', GL);
            else
                if ~hasVT
                    vT = ET / (2 * GT) - 1;
                end
                S = struct('EL', EL, 'ET', ET, ...
                           'vL', vL, 'vT', vT, 'GL', GL);
            end

            C = GetCFromProps(S);
        end
    end
end

%-----------------------------------------------------------------
% Thermal expansion
%-----------------------------------------------------------------
[a1, hasA1] = PickField(P, {'a1'});
[a2, hasA2] = PickField(P, {'a2'});
[a3, hasA3] = PickField(P, {'a3'});

if hasA1 && hasA2 && hasA3
    a6 = [a1; a2; a3; 0; 0; 0];
else
    [aL, hasAL] = PickField(P, {'aL', 'aA', 'a1', 'a', 'am'});
    [aT, hasAT] = PickField(P, {'aT', 'a2', 'a', 'am'});

    if ~hasAL
        aL = 0;
    end

    if ~hasAT
        aT = aL;
    end

    a6 = [aL; aT; aT; 0; 0; 0];
end

end

%=========================================================================
function [val, found] = PickField(S, names)

val = [];
found = false;

for ii = 1:numel(names)
    fn = names{ii};

    if isfield(S, fn) && ~isempty(S.(fn))
        val = S.(fn);
        found = true;
        return;
    end
end

end


function state = WeaveDamageInit(Wp)
% Initialize one independent matrix damage state per tow and pocket.

assert(strcmpi(Wp.Theory,'GMC'), ...
    'Crack-band workflow requires GMC.');

assert(~Wp.UseDirectTow && ~Wp.EnforceTowTI && Wp.Vi==0, ...
    'Use explicit fibre/matrix, EnforceTowTI=false and Vi=0.');

cb=Wp.MatrixCB;

assert(cb.maxTowIter>=1 && ...
    cb.maxTowIter==fix(cb.maxTowIter) && ...
    all(isfinite([cb.tolTow cb.tolWeave cb.tolLam])) && ...
    all([cb.tolTow cb.tolWeave cb.tolLam]>0), ...
    'Invalid solver settings.');

% ============================================================
% CONSTITUENT PROPERTIES
% ============================================================

cp=GetConstitProps();

Constits.Fiber=cp{Wp.Nf};
Constits.Matrix=cp{Wp.Nm};

Vol=struct('Vf',Wp.Vf,'Vi',Wp.Vi);

Tow=RunMicro(Wp.Theory,'Tow',Vol, ...
    Constits,struct('used',true),Wp.towRUCid);

base=TowDamage('init',Tow,cb);

% Check consistency of the undamaged elastic solution

assert(norm(base.Cstar-Tow.Cstar,'fro') / ...
    max(1,norm(Tow.Cstar,'fro'))<1e-6, ...
    'Undamaged GMC and GMCaniso stiffnesses disagree. Check baseline.');

% ============================================================
% WEAVE RUC
% ============================================================

geom=[];

if isfield(Wp,'UseCustomGeom') && ...
        Wp.UseCustomGeom && isfield(Wp,'Geom')

    geom=Wp.Geom;

end

wruc=GetRUC(Constits,Wp.Vf,Wp.Vi,Wp.RUCid,geom);

nx=numel(wruc.d);
ny=numel(wruc.h);
nz=numel(wruc.l);

state=struct('Wp',Wp,'Tow',Tow, ...
    'Constits',Constits,'wruc',wruc, ...
    'nx',nx,'ny',ny,'nz',nz);

state.atow=base.CTEs;

% ============================================================
% MATRIX DAMAGE INITIALIZATION
% ============================================================

mp=MatrixCrackBand('init',Constits.Matrix,cb);

state.Cmat0=mp.C;

state.amat=[Constits.Matrix.aL;
            Constits.Matrix.aT;
            Constits.Matrix.aT;
            0;0;0];

% ============================================================
% ALLOCATE DAMAGE STATE
% ============================================================

state.Cb=cell(nx,ny,nz);

state.ab=state.Cb;
state.Teps=state.Cb;

state.mSt=state.Cb;
state.towState=state.Cb;
state.mPoint=state.Cb;

state.mDam=false(nx,ny,nz);

for q=1:numel(wruc.matsCh)

    c=wruc.matsCh(q);

    if c=='5' || c=='6'

        % Tow orientation

        th=90*(c=='6');

        [state.Cb{q},state.ab{q},state.Teps{q}]= ...
            TowCfull(base.Cstar,base.CTEs, ...
            th,wruc.crimp(q));

        state.towState{q}=base;

        state.mSt{q}=base.matsChDam;

    elseif c=='M'

        % Pure matrix pocket

        state.Cb{q}=mp.C;

        state.ab{q}=state.amat;

        state.Teps{q}=eye(6);

        state.mPoint{q}=mp;

    else

        error('Unsupported weave material: %s',c);

    end

end

end


function [Sb, Eb, Sc, Ec, Cweave, aweave, Ccol] = ...
    WeaveFields(Cb, ab, dx, dy, dz, epsw)
% WEAVEFIELDS
% Recover stresses and strains using thickness-first GMC.
%
% Physical axes:
% x1 = thickness, x2 = warp, x3 = weft
%
% Sb{k,b,g}, Eb{k,b,g}:
%     Individual subcell stress and strain.
%
% Sc{b,g}, Ec{b,g}:
%     Homogenized through-thickness column fields.
%
% Ccol{b,g}:
%     Homogenized column stiffness.

nx = numel(dx);
ny = numel(dy);
nz = numel(dz);

if numel(epsw) ~= 6
    error('WeaveFields: epsw must be a 6x1 vector');
end

epsw = epsw(:);

% ==========================================================
% TWO-STEP HOMOGENIZATION
% ==========================================================

[Cweave, aweave, Acol, Ccol, Atile] = ...
    WeaveHomog(Cb, ab, dx, dy, dz);

Sb = cell(nx,ny,nz);
Eb = cell(nx,ny,nz);

Sc = cell(ny,nz);
Ec = cell(ny,nz);

% ==========================================================
% RECOVER LOCAL FIELDS
% ==========================================================

for b = 1:ny
    for g = 1:nz

        % Step 2: Macro strain -> column strain
        epscol = Atile(b,g).A * epsw;

        Ec{b,g} = epscol;
        Sc{b,g} = Ccol{b,g} * epscol;

        % Step 1: Column strain -> subcell strain
        for k = 1:nx

            Eb{k,b,g} = ...
                Acol{b,g}{k} * epscol;

            Sb{k,b,g} = ...
                Cb{k,b,g} * Eb{k,b,g};

        end

    end
end

end

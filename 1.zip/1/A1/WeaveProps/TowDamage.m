
function out = TowDamage(action,varargin)
% Existing tow damage function, now using only MatrixCrackBand.
%
% Initialization:
%   TowDamage('init',Tow,cb)
%
% Damage calculation:
%   TowDamage('trial',committedTowState,epsTow)

switch lower(action)

    case 'init'

        Tow=varargin{1};
        cb=varargin{2};

        R=Tow.RUC;

        p=cell(R.NB,R.NG);

        R.C=p;
        R.alpha=p;

        pm=MatrixCrackBand('init',Tow.Matrix,cb);

        Cf=GetCFromProps(Tow.Fiber);

        % ================================================
        % INITIALIZE SUBCELL STIFFNESS
        % ================================================

        for q=1:numel(R.matsCh)

            switch R.matsCh(q)

                case 'M'

                    p{q}=pm;

                    R.C{q}=pm.C;

                    m=Tow.Matrix;

                case 'F'

                    R.C{q}=Cf;

                    m=Tow.Fiber;

                otherwise

                    error('Unsupported tow material: %s', ...
                        R.matsCh(q));

            end

            R.alpha{q}=[m.aL;m.aT;m.aT;0;0;0];

        end

        % Initial elastic tow homogenization

        [C,a,A]=GMCaniso(R);

        out=struct('RUC',R, ...
            'p',{p}, ...
            'Cstar',C, ...
            'CTEs',a, ...
            'As',A, ...
            'cb',cb, ...
            'matsChDam',R.matsCh, ...
            'nfail',0);

    case 'trial'

        old=varargin{1};

        e=varargin{2};

        e=e(:);

        R=old.RUC;

        C=old.Cstar;

        a=old.CTEs;

        A=old.As;

        % Identify matrix subcells only

        ids=find(R.matsCh=='M');

        cb=old.cb;

        % ================================================
        % GMC DAMAGE ITERATION
        % ================================================

        for it=1:cb.maxTowIter

            P=old.p;

            Rnew=R;

            err=0;

            for q=ids(:).'

                % Calculate local strain and matrix damage

                P{q}=MatrixCrackBand('trial', ...
                    old.p{q},A(q).A*e);

                % Update matrix subcell stiffness

                Rnew.C{q}=P{q}.C;

                % Relative stiffness change

                err=max(err, ...
                    norm(Rnew.C{q}-R.C{q},'fro') / ...
                    max(1,norm(Rnew.C{q},'fro')));

            end

            % ============================================
            % CHECK CONVERGENCE
            % ============================================

            if err<cb.tolTow

                R=Rnew;

                if err>0

                    [C,a,A]=GMCaniso(R);

                end

                out=old;

                out.RUC=R;

                out.p=P;

                out.Cstar=C;

                out.CTEs=a;

                out.As=A;

                out.matsChDam=R.matsCh;

                % Mark damaged matrix cells for plotting

                for q=ids(:).'

                    if P{q}.d>1e-12

                        out.matsChDam(q)='2';

                    end

                end

                out.nfail=nnz(out.matsChDam=='2');

                return

            end

            % ============================================
            % NUMERICAL RELAXATION
            % ============================================

            % Relax computational stiffness, not the
            % previously committed damage history.

            for q=ids(:).'

                R.C{q}=0.5*(R.C{q}+Rnew.C{q});

            end

            % Rehomogenize the damaged tow

            [C,a,A]=GMCaniso(R);

        end

        error('TowDamage:Nonconvergence', ...
            ['Tow stiffness residual %.3e. ' ...
             'Reduce load increment.'],err);

    otherwise

        error('Unknown TowDamage action: %s',action);

end

end


function [Wp] = WeaveProblemDef()
% +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% Purpose: Define the weave problem, exactly as MicroProblemDef does for
%          NASA's tow problems. EDIT THIS FILE, then Run WeaveAnalysis.m
%          or WeaveSimDamage.m. You never need to run this file itself.
% Output:
% - Wp: struct of weave problem settings
% +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

% -- Micromechanics theory at the tow scale

Wp.Theory = 'GMC';

% -- Tow scale

Wp.towRUCid = 2;
Wp.Vf = 0.65;
Wp.Vi = 0;
Wp.Nf = 23;
Wp.Nm = 24;

Wp.EnforceTowTI = false;

% -- Weave scale

Wp.RUCid = 401;

% -- Damage settings

Wp.NINC = 20;
Wp.NITER = 250;

Wp.epswMax = [0; 0.001; 0; 0; 0; 0];

Wp.Figures = true;

Wp.UseDirectTow = false;

% -- Direct tow inputs (elastic workflow only)

Wp.TowProps.EA = 47.77;
Wp.TowProps.ET = 18.06;
Wp.TowProps.vA = 0.314;
Wp.TowProps.GA = 3.877;
Wp.TowProps.GT = 7.2138;
Wp.TowProps.Vf = 0.65;

Wp.MatrixProps.E = 3.5;
Wp.MatrixProps.v = 0.35;

% -- Geometry

Wp.Geom.a = 0.5385;
Wp.Geom.g = 0.4615;
Wp.Geom.H = 0.3077;

% ============================================================
% MATRIX CRACK-BAND DAMAGE MODEL
% Ricks et al. (2022)
%
% Exploratory literature-informed porous alumina inputs.
% These are not a validated material parameter set.
% ============================================================

% Normal cohesive strength [MPa]

Wp.MatrixCB.Xm_MPa = 33;

% Shear cohesive strength [MPa]

Wp.MatrixCB.Ym_MPa = 33;

% Mode-I fracture energy [N/mm]

Wp.MatrixCB.GIC_N_per_mm = 0.020;

% Mode-II fracture energy [N/mm]

Wp.MatrixCB.GIIC_N_per_mm = 0.020;

% Fixed characteristic length [mm]

Wp.MatrixCB.lc_mm = 0.020;

% -- Numerical settings

Wp.MatrixCB.residual = 1e-4;

Wp.MatrixCB.maxTowIter = 500;

Wp.MatrixCB.tolTow = 1e-5;

Wp.MatrixCB.tolWeave = 1e-5;

Wp.MatrixCB.tolLam = 1e-5;

% ============================================================
% LAMINATE SETTINGS
% ============================================================

Wp.Mat = 220;

Wp.NxMax = 1000;

Wp.StrainControl = true;

Wp.epsxMax = 0.009;

Wp.Orient = [0 90 0 90];

Wp.tply = [0.15 0.15 0.15 0.15];

end

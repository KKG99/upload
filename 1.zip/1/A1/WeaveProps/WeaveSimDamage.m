% +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% PRESS RUN ON THIS FILE. Weave progressive damage, stress-strain curve.
% Settings are in WeaveProblemDef.m - edit that, not this.
% This takes about a minute. It is not frozen.
% +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
clear; clc;
hereDir = fileparts(mfilename('fullpath'));
a1Dir   = fileparts(hereDir);
addpath(a1Dir, fullfile(a1Dir,'Functions','Utilities'), fullfile(a1Dir,'Functions','WriteResults'), ...
    fullfile(a1Dir,'Functions','Micromechanics'), fullfile(a1Dir,'Functions','Margins'), ...
    fullfile(a1Dir,'Functions','Damage'), hereDir);

[Wp] = WeaveProblemDef();
if ~isfield(Wp,'towRUCid') || isempty(Wp.towRUCid)
    Wp.towRUCid = 7;    % fallback if not specified in WeaveProblemDef
end

disp(['Weave Damage - RUC ' num2str(Wp.RUCid) ', ' num2str(Wp.NINC) ' increments']);

[Hist, Weave, Tow, wruc] = SimWeaveDamage(Wp);

[~, loadIdx] = max(abs(Wp.epswMax));
if isempty(loadIdx) || max(abs(Wp.epswMax)) == 0, loadIdx = 2; end
compNames = {'11','22','33','23','13','12'};
[pk, ip] = max(Hist.sig(:,loadIdx));
fprintf('\npeak sig%s = %.2f MPa at eps%s = %.6f\n', compNames{loadIdx}, pk, compNames{loadIdx}, Hist.eps(ip,loadIdx));

if Wp.Figures
    figure;
    plot(Hist.eps(:,loadIdx), Hist.sig(:,loadIdx), 'b-o', 'MarkerSize', 4);
    xlabel(['\epsilon_{' compNames{loadIdx} '}']); ylabel(['\sigma_{' compNames{loadIdx} '}  [MPa]']);
    title(['Weave RUC ' num2str(Wp.RUCid) ' - progressive damage']);
    grid on;

end

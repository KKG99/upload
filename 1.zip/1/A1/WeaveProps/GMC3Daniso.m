
function [Cstar, CTEs, As, info] = GMC3Daniso(RUC)
% GMC3DANISO
% First-order triply periodic GMC with full anisotropic 6x6 C.
%
% Axes: x1, x2, x3
% Voigt order: [11 22 33 23 13 12]
% Engineering shear strains: [e11 e22 e33 g23 g13 g12]
%
% Inputs:
% RUC.NA, RUC.NB, RUC.NG
% RUC.d, RUC.h, RUC.l
% RUC.C{a,b,g}       6x6 subcell stiffness
% RUC.alpha{a,b,g}   6x1 thermal expansion (optional)
%
% Outputs:
% Cstar              Effective 6x6 stiffness
% CTEs               Effective 6x1 CTE
% As(a,b,g).A        Mechanical strain concentration
% As(a,b,g).AT       Thermal strain concentration
% info               Numerical diagnostics
%
% Independent first-order implementation, not verified
% equivalent to the original NASA MAC/GMC MOD=3 solver.

NA = RUC.NA;
NB = RUC.NB;
NG = RUC.NG;

assert(isscalar(NA) && isscalar(NB) && isscalar(NG) && ...
    all([NA NB NG] >= 1) && ...
    all(mod([NA NB NG],1)==0), ...
    'NA, NB, NG must be positive integers.');

d = RUC.d(:).';
h = RUC.h(:).';
l = RUC.l(:).';

assert(numel(d)==NA && numel(h)==NB && ...
    numel(l)==NG && ...
    all(isfinite([d h l])) && ...
    all([d h l]>0), ...
    'Invalid RUC dimensions.');

assert(iscell(RUC.C) && numel(RUC.C)==NA*NB*NG, ...
    'Incorrect RUC.C dimensions.');

if isfield(RUC,'alpha') && ~isempty(RUC.alpha)
    assert(iscell(RUC.alpha) && ...
        numel(RUC.alpha)==NA*NB*NG, ...
        'Incorrect RUC.alpha dimensions.');
    aCell = RUC.alpha;
else
    aCell = repmat({zeros(6,1)},NA,NB,NG);
end

N = NA*NB*NG;

Ccell = cell(N,1);
alpha = zeros(6,N);
weights = zeros(N,1);

vol = sum(d)*sum(h)*sum(l);

for g = 1:NG
    for b = 1:NB
        for a = 1:NA

            s = sub2ind([NA NB NG],a,b,g);
            Ci = RUC.C{s};

            assert(isequal(size(Ci),[6 6]) && ...
                all(isfinite(Ci(:))), ...
                'Invalid stiffness at subcell %d.',s);

            Ccell{s} = Ci;
            ai = aCell{s};

            assert(numel(ai)==6 && all(isfinite(ai(:))), ...
                'Invalid CTE at subcell %d.',s);

            alpha(:,s) = ai(:);
            weights(s) = d(a)*h(b)*l(g)/vol;

        end
    end
end

% ============================================================
% Assemble the 6N x 6N system
% ============================================================

ng = NB*NG + NA*NG + NA*NB + NA + NB + NG;
nt = 6*N - ng;

K = zeros(6*N,6);
fT = zeros(6*N,1);

cap = max(256,100*N);

II = zeros(cap,1);
JJ = zeros(cap,1);
VV = zeros(cap,1);

nz = 0;
row = 0;

% ============================================================
% Geometric displacement compatibility
% ============================================================

% Normal strain e11: compatibility along x1

for b = 1:NB
    for g = 1:NG

        row = row+1;
        K(row,1) = sum(d);

        for a = 1:NA
            s = sub2ind([NA NB NG],a,b,g);
            addEntry(s,1,d(a));
        end

    end
end

% Normal strain e22: compatibility along x2

for a = 1:NA
    for g = 1:NG

        row = row+1;
        K(row,2) = sum(h);

        for b = 1:NB
            s = sub2ind([NA NB NG],a,b,g);
            addEntry(s,2,h(b));
        end

    end
end

% Normal strain e33: compatibility along x3

for a = 1:NA
    for b = 1:NB

        row = row+1;
        K(row,3) = sum(l);

        for g = 1:NG
            s = sub2ind([NA NB NG],a,b,g);
            addEntry(s,3,l(g));
        end

    end
end

% Shear gamma23: compatibility in x2-x3

for a = 1:NA

    row = row+1;
    K(row,4) = sum(h)*sum(l);

    for b = 1:NB
        for g = 1:NG
            s = sub2ind([NA NB NG],a,b,g);
            addEntry(s,4,h(b)*l(g));
        end
    end

end

% Shear gamma13: compatibility in x1-x3

for b = 1:NB

    row = row+1;
    K(row,5) = sum(d)*sum(l);

    for a = 1:NA
        for g = 1:NG
            s = sub2ind([NA NB NG],a,b,g);
            addEntry(s,5,d(a)*l(g));
        end
    end

end

% Shear gamma12: compatibility in x1-x2

for g = 1:NG

    row = row+1;
    K(row,6) = sum(d)*sum(h);

    for a = 1:NA
        for b = 1:NB
            s = sub2ind([NA NB NG],a,b,g);
            addEntry(s,6,d(a)*h(b));
        end
    end

end

assert(row==ng,'Incorrect geometry equation count.');

% ============================================================
% Traction continuity across x1 interfaces
% ============================================================

% sigma11

for b = 1:NB
    for g = 1:NG
        for a = 2:NA

            s1 = sub2ind([NA NB NG],a-1,b,g);
            s2 = sub2ind([NA NB NG],a,b,g);

            addStressEq(s1,s2,1);

        end
    end
end

% ============================================================
% Traction continuity across x2 interfaces
% ============================================================

% sigma22

for a = 1:NA
    for g = 1:NG
        for b = 2:NB

            s1 = sub2ind([NA NB NG],a,b-1,g);
            s2 = sub2ind([NA NB NG],a,b,g);

            addStressEq(s1,s2,2);

        end
    end
end

% ============================================================
% Traction continuity across x3 interfaces
% ============================================================

% sigma33

for a = 1:NA
    for b = 1:NB
        for g = 2:NG

            s1 = sub2ind([NA NB NG],a,b,g-1);
            s2 = sub2ind([NA NB NG],a,b,g);

            addStressEq(s1,s2,3);

        end
    end
end

% ============================================================
% Shear traction continuity
% ============================================================

% sigma23: continuous across x2 and x3

for a = 1:NA

    base = sub2ind([NA NB NG],a,1,1);

    for b = 1:NB
        for g = 1:NG

            if b==1 && g==1
                continue
            end

            s = sub2ind([NA NB NG],a,b,g);
            addStressEq(base,s,4);

        end
    end

end

% sigma13: continuous across x1 and x3

for b = 1:NB

    base = sub2ind([NA NB NG],1,b,1);

    for a = 1:NA
        for g = 1:NG

            if a==1 && g==1
                continue
            end

            s = sub2ind([NA NB NG],a,b,g);
            addStressEq(base,s,5);

        end
    end

end

% sigma12: continuous across x1 and x2

for g = 1:NG

    base = sub2ind([NA NB NG],1,1,g);

    for a = 1:NA
        for b = 1:NB

            if a==1 && b==1
                continue
            end

            s = sub2ind([NA NB NG],a,b,g);
            addStressEq(base,s,6);

        end
    end

end

assert(row==6*N && row-ng==nt, ...
    'Incorrect final equation count.');

% ============================================================
% Assemble and solve sparse GMC system
% ============================================================

M = sparse( ...
    II(1:nz),JJ(1:nz),VV(1:nz),6*N,6*N);

if any(~isfinite(nonzeros(M)))
    error('Invalid GMC equation matrix.');
end

X = M\[K,fT];

if any(~isfinite(X(:)))
    error('Invalid or singular GMC solution.');
end

residual = norm(M*X-[K,fT],'fro') / ...
    max(1,norm([K,fT],'fro'));

if residual > 1e-7
    warning('GMC3Daniso: residual %.3e',residual);
end

% ============================================================
% Effective stiffness and localization
% ============================================================

Cstar = zeros(6);
thermalStress = zeros(6,1);
strainAvg = zeros(6);

As = repmat( ...
    struct('A',[],'AT',[],'C',[],'alpha',[]), ...
    NA,NB,NG);

for s = 1:N

    aa = X((s-1)*6+(1:6),1:6);
    et = X((s-1)*6+(1:6),7);

    As(s).A = aa;
    As(s).AT = et;
    As(s).C = Ccell{s};
    As(s).alpha = alpha(:,s);

    Cstar = Cstar + ...
        weights(s)*Ccell{s}*aa;

    strainAvg = strainAvg + weights(s)*aa;

    thermalStress = thermalStress + ...
        weights(s)*Ccell{s}*(et-alpha(:,s));

end

CTEs = -Cstar\thermalStress;

info.numSubcells = N;
info.numEquations = 6*N;
info.linearResidual = residual;

info.avgStrainResidual = ...
    norm(strainAvg-eye(6),'fro');

info.symmetryResidual = ...
    norm(Cstar-Cstar.','fro') / ...
    max(1,norm(Cstar,'fro'));

% ============================================================
% Nested function: sparse matrix insertion
% ============================================================

    function addEntry(s,component,coefficient)

        nz = nz+1;

        if nz > numel(II)

            II = [II;zeros(cap,1)]; %#ok<AGROW>
            JJ = [JJ;zeros(cap,1)]; %#ok<AGROW>
            VV = [VV;zeros(cap,1)]; %#ok<AGROW>

        end

        II(nz) = row;
        JJ(nz) = 6*(s-1)+component;
        VV(nz) = coefficient;

    end

% ============================================================
% Nested function: interfacial traction equilibrium
% ============================================================

    function addStressEq(s1,s2,component)

        row = row+1;

        ci = Ccell{s1};
        cj = Ccell{s2};

        for q = 1:6

            addEntry(s1,q, ci(component,q));
            addEntry(s2,q,-cj(component,q));

        end

        fT(row) = ...
            ci(component,:)*alpha(:,s1) - ...
            cj(component,:)*alpha(:,s2);

    end

end

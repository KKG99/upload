
function [Cweave,aweave,state,Sb,Sc,ndam,nsub] = ...
    WeavePlyDamage(state,epsw,NITER,commitFlag)

% Existing weave damage function.
% Matrix-only mixed-mode crack-band damage.

if nargin<3 || isempty(NITER)

    NITER=state.Wp.NITER;

end

if nargin<4 || isempty(commitFlag)

    commitFlag=true;

end

% Previous converged damage state

old=state;

R=old.wruc;

cb=old.Wp.MatrixCB;

C=old.Cb;

a=old.ab;

% ============================================================
% WEAVE DAMAGE ITERATION
% ============================================================

for it=1:NITER

    % Calculate local weave block strains

    [~,Eb]=WeaveFields( ...
        C,a,R.d,R.h,R.l,epsw);

    trial=old;

    err=0;

    for q=1:numel(R.matsCh)

        c=R.matsCh(q);

        % ================================================
        % TOW BLOCKS
        % ================================================

        if c=='5' || c=='6'

            % Transform strains into tow coordinates

            e=old.Teps{q}*Eb{q};

            % Calculate matrix damage inside tow

            t=TowDamage('trial',old.towState{q},e);

            trial.towState{q}=t;

            trial.mSt{q}=t.matsChDam;

            % Transform homogenized tow stiffness
            % back into weave coordinates

            [trial.Cb{q},trial.ab{q}]=TowCfull( ...
                t.Cstar,t.CTEs,90*(c=='6'),R.crimp(q));

        % ================================================
        % PURE MATRIX POCKETS
        % ================================================

        elseif c=='M'

            p=MatrixCrackBand('trial', ...
                old.mPoint{q},Eb{q});

            trial.mPoint{q}=p;

            trial.mDam(q)=p.d>1e-12;

            trial.Cb{q}=p.C;

        else

            error('Unsupported weave material: %s',c);

        end

        % Relative stiffness change

        err=max(err, ...
            norm(trial.Cb{q}-C{q},'fro') / ...
            max(1,norm(trial.Cb{q},'fro')));

    end

    % ====================================================
    % CONVERGENCE
    % ====================================================

    if err<cb.tolWeave

        [Sb,~,Sc,~,Cweave,aweave]=WeaveFields( ...
            trial.Cb,trial.ab,R.d,R.h,R.l,epsw);

        % Count damaged matrix pockets

        ndam=nnz(trial.mDam);

        nsub=0;

        % Count damaged matrix cells inside tows

        for q=1:numel(R.matsCh)

            if R.matsCh(q)=='5' || R.matsCh(q)=='6'

                n=trial.towState{q}.nfail;

                nsub=nsub+n;

                ndam=ndam+(n>0);

            end

        end

        % Commit converged damage history

        if commitFlag

            state=trial;

        end

        return

    end

    % ====================================================
    % NUMERICAL RELAXATION
    % ====================================================

    % Relax the weave iterate only.
    % The previous committed state remains unchanged.

    for q=1:numel(C)

        C{q}=0.5*(C{q}+trial.Cb{q});

        a{q}=trial.ab{q};

    end

end

error('WeavePlyDamage:Nonconvergence', ...
    ['Weave stiffness residual %.3e. ' ...
     'Reduce load increment.'],err);

end


function [Hist, Weave, Tow, wruc] = SimWeaveDamage(Wp)
% +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% Purpose: Progressive-damage tensile response of a woven ply, driven and
%          drawn the same way as NASA's MicroSimDamage:
%            - ramp the load in NINC increments,
%            - live 3-panel figure: stress-strain / von Mises / block failure,
%            - console progress "* INC = i out of N *" each step.
%
% Input (struct Wp):
% - Wp.epswMax : 6x1 final macro strain in weave axes
% - Wp.NINC    : load increments
% - Wp.NITER   : max equilibrium iterations per increment
% - Wp.MatrixCB : fixed-lc crack-band inputs
% - Wp.Figures : true for the live plots
%
% Output:
% - Hist: .eps .sig .ndam per increment
% - Weave, Tow, wruc: as from RunWeave, at the final state
% +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

hereDir = fileparts(mfilename('fullpath'));

a1Dir = fileparts(hereDir);

addpath(a1Dir, ...
    fullfile(a1Dir,'Functions','Utilities'), ...
    fullfile(a1Dir,'Functions','WriteResults'), ...
    fullfile(a1Dir,'Functions','Micromechanics'), ...
    fullfile(a1Dir,'Functions','Margins'), ...
    fullfile(a1Dir,'Functions','Damage'), ...
    hereDir);

% ============================================================
% PROBLEM DEFINITION
% ============================================================

if nargin < 1 || isempty(Wp)

    Wp = WeaveProblemDef();

end

if ~isfield(Wp,'NITER')

    Wp.NITER = 5;

end

if ~isfield(Wp,'NINC')

    Wp.NINC = 100;

end

if ~isfield(Wp,'epswMax')

    error('SimWeaveDamage: Wp.epswMax is required');

end

if ~isfield(Wp,'Figures')

    Wp.Figures = true;

end

% ============================================================
% INITIALIZE DAMAGE STATE
% ============================================================

state = WeaveDamageInit(Wp);

nx = state.nx;

ny = state.ny;

nz = state.nz;

wruc = state.wruc;

% Totals for damage reporting

totBlk = nx*ny*nz;

towBlk = nnz(ismember(wruc.matsCh,'56'));

totSub = towBlk * ...
    state.Tow.RUC.NB * state.Tow.RUC.NG;

% ============================================================
% ALLOCATE HISTORY
% ============================================================

N = Wp.NINC;

Hist.eps = zeros(N+1,6);

Hist.sig = zeros(N+1,6);

Hist.ndam = zeros(N+1,1);

Hist.nsub = zeros(N+1,1);

strainhist = zeros(N+1,1);

stresshist = zeros(N+1,1);

[~,loadIdx] = max(abs(Wp.epswMax));

if isempty(loadIdx) || max(abs(Wp.epswMax)) == 0

    loadIdx = 2;

end

compNames = {'11','22','33','23','13','12'};

cLbl = compNames{loadIdx};

damfig = 0;

ndamPrev = -1;

% ============================================================
% LOADING INCREMENTS
% ============================================================

for INC = 0:N

    pct = INC/N;

    epsw = Wp.epswMax*pct;

    % --------------------------------------------------------
    % ELASTIC BASELINE
    % --------------------------------------------------------

    if INC == 0

        [Sb,~,Sc,~,Cweave,aweave] = ...
            WeaveFields(state.Cb,state.ab, ...
            wruc.d,wruc.h,wruc.l,epsw);

        ndam = 0;

        nsub = 0;

    % --------------------------------------------------------
    % MATRIX CRACK-BAND DAMAGE
    % --------------------------------------------------------

    else

        [Cweave,aweave,state,Sb,Sc,ndam,nsub] = ...
            WeavePlyDamage( ...
            state,epsw,Wp.NITER,true);

    end

    % ========================================================
    % MACROSCOPIC STRESS
    % ========================================================

    sig = Cweave*epsw;

    ic = INC+1;

    Hist.eps(ic,:) = epsw.';

    Hist.sig(ic,:) = sig.';

    Hist.ndam(ic) = ndam;

    Hist.nsub(ic) = nsub;

    strainhist(ic) = epsw(loadIdx);

    stresshist(ic) = sig(loadIdx);

    % ========================================================
    % COMMAND WINDOW OUTPUT
    % ========================================================

    disp(' ');

    disp('*****************************************************');

    disp(['* INC = ',num2str(INC), ...
        '  out of ',num2str(N)]);

    disp('*****************************************************');

    fprintf(['   eps%s = %9.6f  sig%s = %10.3f  ' ...
        'blocks = %4d/%d  subcells = %5d/%d\n'], ...
        cLbl,epsw(loadIdx), ...
        cLbl,sig(loadIdx), ...
        ndam,totBlk,nsub,totSub);

    % ========================================================
    % LIVE FIGURES
    % ========================================================

    if Wp.Figures

        newfail = (ndam ~= ndamPrev);

        damfig = WeaveDamageWrite( ...
            damfig,state,Sb, ...
            strainhist(1:ic),stresshist(1:ic), ...
            INC,newfail,ndam,nsub);

        ndamPrev = ndam;

    end

end

% ============================================================
% FINAL EFFECTIVE PROPERTIES
% ============================================================

Weave.RUCid = Wp.RUCid;

Weave.Cstar = Cweave;

Weave = AddEngProps(Weave,Cweave,aweave);

Tow = state.Tow;

wruc = state.wruc;

if Wp.Figures

    PlotWeaveBlocks3D(state, ...
        ['Weave RUC ' num2str(Wp.RUCid) ...
        ' - failed blocks, final']);

end

end

%=========================================================================%
% Live 3-panel figure, mirroring NASA's DamageWrite layout.
%=========================================================================%

function [damfig] = WeaveDamageWrite( ...
    damfig,state,Sb,strainhist,stresshist, ...
    INC,newfail,ndam,nsub)

nx = state.nx;

ny = state.ny;

nz = state.nz;

wruc = state.wruc;

totBlk = nx*ny*nz;

totSub = nnz(ismember(wruc.matsCh,'56')) * ...
    state.Tow.RUC.NB * state.Tow.RUC.NG;

if INC == 0

    damfig = figure('units','normalized', ...
        'outerposition',[0 0.5 1 0.5]);

else

    figure(damfig);

end

% ============================================================
% PANEL 1: STRESS-STRAIN CURVE
% ============================================================

subplot(1,3,1);

plot(strainhist,stresshist/1,'-o','MarkerSize',3);

title('stress vs. strain');

xlabel('strain');

ylabel('stress (MPa)','rotation',90);

grid on;

drawnow;

if INC == 0 || newfail

    % Top-view map in x2 warp and x3 weft:
    % tow = 1, matrix = 2, damaged region = 3.

    map = 2*ones(ny,nz);

    vm = zeros(ny,nz);

    for b = 1:ny

        for g = 1:nz

            kk = nx;

            % Find uppermost tow

            for k = nx:-1:1

                c = wruc.matsCh(k,b,g);

                if c == '5' || c == '6'

                    kk = k;

                    map(b,g) = 1;

                    break;

                end

            end

            % Local stress

            s = Sb{kk,b,g};

            % Von Mises stress

            vm(b,g) = sqrt( ...
                (s(1)-s(2))^2 + ...
                (s(2)-s(3))^2 + ...
                (s(1)-s(3))^2 + ...
                6*s(4)^2 + ...
                6*s(5)^2 + ...
                6*s(6)^2)/sqrt(2);

            % Identify damaged matrix regions

            if wruc.matsCh(kk,b,g) == 'M'

                if state.mDam(kk,b,g)

                    map(b,g) = 3;

                end

            else

                if any(ismember(state.mSt{kk,b,g}(:),'123'))

                    map(b,g) = 3;

                end

            end

        end

    end

    % Pad maps for pcolor

    Mp = padmap(map.',nz,ny);

    Vp = padmap(vm.',nz,ny);

    [X,Y] = meshgrid(0:ny,0:nz);

    % ========================================================
    % PANEL 2: VON MISES STRESS
    % ========================================================

    subplot(1,3,2);

    colormap(jet);

    pcolor(X,Y,Vp);

    shading interp;

    colorbar;

    axis image;

    xlabel('x_2 (warp, load)');

    ylabel('x_3 (weft)');

    title(['von Mises stress, x_1 = thru-thk, INC = ', ...
        num2str(INC)],'FontSize',12);

    drawnow;

    % ========================================================
    % PANEL 3: DAMAGE DISTRIBUTION
    % ========================================================

    subplot(1,3,3);

    colormap(jet);

    pcolor(X,Y,Mp);

    shading faceted;

    caxis([1 3]);

    axis image;

    xlabel('x_2 (warp, load)');

    ylabel('x_3 (weft)');

    title(['Block failure (red), INC=',num2str(INC), ...
        ':  blocks=',num2str(ndam),'/',num2str(totBlk), ...
        '  subcells=',num2str(nsub),'/',num2str(totSub)], ...
        'FontSize',11);

    drawnow;

end

end

%=========================================================================%
% LOCAL FUNCTION: PAD MAP
%=========================================================================%

function [P] = padmap(M,ny,nx)

P = zeros(ny+1,nx+1);

P(1:ny,1:nx) = M;

P(ny+1,:) = P(ny,:);

P(:,nx+1) = P(:,nx);

end

%=========================================================================%
% LOCAL FUNCTION: ENGINEERING CONSTANTS
%=========================================================================%

function [s] = AddEngProps(s,C,a)

[E] = GetEffPropsFromC(C);

s.E1 = E.E1;

s.E2 = E.E2;

s.E3 = E.E3;

s.v12 = E.v12;

s.v13 = E.v13;

s.v23 = E.v23;

s.G12 = E.G12;

s.G13 = E.G13;

s.G23 = E.G23;

s.a1 = a(1);

s.a2 = a(2);

s.a3 = a(3);

end

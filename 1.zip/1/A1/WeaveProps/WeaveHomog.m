
function [Cweave, aweave, Acol, Ccol, Atile] = ...
    WeaveHomog(Cb, ab, dx, dy, dz)
% WEAVEHOMOG
% Thickness-first two-step homogenization using GMC3Daniso.
%
% Physical axes:
% x1 = thickness
% x2 = warp
% x3 = weft
%
% Both stages use triply periodic GMC.
% Full 6x6 anisotropic stiffness is preserved.
% No coordinate permutation is used.
%
% Inputs:
% Cb{k,b,g} = block stiffness, 6x6
% ab{k,b,g} = block CTE, 6x1
% dx = thickness layer dimensions
% dy = warp direction dimensions
% dz = weft direction dimensions

nx = numel(dx);
ny = numel(dy);
nz = numel(dz);

if ~iscell(Cb) || ~iscell(ab) || ...
        numel(Cb) ~= nx*ny*nz || ...
        numel(ab) ~= nx*ny*nz

    error('WeaveHomog: Incorrect block dimensions.');

end

Ccol  = cell(ny,nz);
acolC = cell(ny,nz);
Acol  = cell(ny,nz);

% ============================================================
% STEP 1: THROUGH-THICKNESS HOMOGENIZATION
% ============================================================

for b = 1:ny
    for g = 1:nz

        R1 = struct();

        R1.NA = nx;
        R1.NB = 1;
        R1.NG = 1;

        R1.d = dx(:).';
        R1.h = 1;
        R1.l = 1;

        R1.C = cell(nx,1,1);
        R1.alpha = cell(nx,1,1);

        for k = 1:nx

            R1.C{k,1,1} = Cb{k,b,g};
            R1.alpha{k,1,1} = ab{k,b,g}(:);

        end

        [Ccol{b,g},acolC{b,g},A1] = GMC3Daniso(R1);

        Acol{b,g} = cell(1,nx);

        for k = 1:nx
            Acol{b,g}{k} = A1(k,1,1).A;
        end

    end
end

% ============================================================
% STEP 2: IN-PLANE HOMOGENIZATION
% ============================================================

R2 = struct();

R2.NA = 1;
R2.NB = ny;
R2.NG = nz;

R2.d = 1;
R2.h = dy(:).';
R2.l = dz(:).';

R2.C = cell(1,ny,nz);
R2.alpha = cell(1,ny,nz);

for b = 1:ny
    for g = 1:nz

        R2.C{1,b,g} = Ccol{b,g};
        R2.alpha{1,b,g} = acolC{b,g};

    end
end

[Cweave,aweave,A2] = GMC3Daniso(R2);

Atile = repmat( ...
    struct('A',zeros(6)),ny,nz);

for b = 1:ny
    for g = 1:nz
        Atile(b,g).A = A2(1,b,g).A;
    end
end

end

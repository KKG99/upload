% +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% PRESS RUN ON THIS FILE. Laminate progressive damage, weave plies, CLT.
% Settings are in WeaveProblemDef.m - edit that, not this.
% Slow: about a minute per load increment.
% +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
clear; clc;
hereDir = fileparts(mfilename('fullpath'));
a1Dir   = fileparts(hereDir);
addpath(a1Dir, fullfile(a1Dir,'Functions','Utilities'), fullfile(a1Dir,'Functions','WriteResults'), ...
        fullfile(a1Dir,'Functions','Micromechanics'), fullfile(a1Dir,'Functions','Margins'), ...
        fullfile(a1Dir,'Functions','Damage'), fullfile(a1Dir,'Functions','CLT'), hereDir);

[Wp] = WeaveProblemDef();
if ~isfield(Wp,'towRUCid') || isempty(Wp.towRUCid)
    Wp.towRUCid = 7;
end

Geometry.Orient = Wp.Orient;
Geometry.plymat = repmat(Wp.Mat, 1, numel(Wp.Orient));
Geometry.tply   = Wp.tply;
ninc = 20;
if isfield(Wp,'NINC') && ~isempty(Wp.NINC), ninc = Wp.NINC; end

disp(['Laminate Damage - [' num2str(Wp.Orient) '], weave RUC ' num2str(Wp.RUCid)]);

[Hist, LamResults, plyprops, states] = WeaveLamSimDamage(Wp, Geometry, Wp.NxMax, ninc);

if Wp.Figures
figure;
plot(Hist.ex, Hist.Nx, 'b-o', 'MarkerSize', 4);
xlabel('\epsilon_x'); ylabel('N_x  [N/mm]');
title('Cross-ply laminate, woven plies');
grid on;

% -- 3-D failed-block picture of every ply, like NASA's Subcell Failure panel
for i = 1:numel(states)
    PlotWeaveBlocks3D(states{i}, ...
        ['ply ' num2str(i) ' (' num2str(Wp.Orient(i)) 'deg) - failed blocks, final']);
end

end

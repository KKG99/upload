
function [Hist,LamResults,plyprops,states] = ...
    WeaveLamSimDamage(Wp,Geometry,NxMax,NINC)

% +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% Purpose: Progressive-damage response of a laminate whose plies are woven.
%
% CLT calculates the ply strains.
% WeavePlyDamage updates the matrix damage at the weave scale.
% CLT is repeated using the updated stiffness.
%
% Input:
% - Wp: weave problem definition
% - Geometry: Orient, plymat, tply
% - NxMax: final applied Nx [N/mm]
% - NINC: number of load increments
%
% Output:
% - Hist: laminate stress, strain and damage histories
% - LamResults: final CLT result
% - plyprops: final damaged ply properties
% - states: individual ply damage states
% +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

hereDir = fileparts(mfilename('fullpath'));

a1Dir = fileparts(hereDir);

addpath(a1Dir, ...
    fullfile(a1Dir,'Functions','Utilities'), ...
    fullfile(a1Dir,'Functions','WriteResults'), ...
    fullfile(a1Dir,'Functions','Micromechanics'), ...
    fullfile(a1Dir,'Functions','Margins'), ...
    fullfile(a1Dir,'Functions','Damage'), ...
    fullfile(a1Dir,'Functions','CLT'), ...
    hereDir);

% ============================================================
% PROBLEM DEFINITION
% ============================================================

if nargin < 1 || isempty(Wp)

    Wp = WeaveProblemDef();

end

if ~isfield(Wp,'NITER')

    Wp.NITER = 3;

end

if ~isfield(Wp,'Figures')

    Wp.Figures = true;

end

if ~isfield(Wp,'StrainControl')

    Wp.StrainControl = false;

end

if ~isfield(Wp,'epsxMax')

    Wp.epsxMax = 0.006;

end

for f = {'Mat','RUCid','towRUCid','Vf','Vi','Nf','Nm','Theory'}

    if ~isfield(Wp,f{1})

        error(['WeaveLamSimDamage: Wp.' ...
            f{1} ' is required']);

    end

end

% ============================================================
% LAMINATE GEOMETRY
% ============================================================

if nargin < 2 || isempty(Geometry)

    if isfield(Wp,'Orient') && ~isempty(Wp.Orient)

        Geometry.Orient = Wp.Orient;

    else

        Geometry.Orient = [0 90 90 0];

    end

    if isfield(Wp,'tply') && ...
        numel(Wp.tply) == numel(Geometry.Orient)

        Geometry.tply = Wp.tply;

    else

        Geometry.tply = ...
            0.15*ones(1,numel(Geometry.Orient));

    end

    Geometry.plymat = repmat( ...
        Wp.Mat,1,numel(Geometry.Orient));

end

if nargin < 3 || isempty(NxMax)

    if isfield(Wp,'NxMax') && ~isempty(Wp.NxMax)

        NxMax = Wp.NxMax;

    else

        NxMax = 500;

    end

end

if nargin < 4 || isempty(NINC)

    if isfield(Wp,'NINC') && ~isempty(Wp.NINC)

        NINC = Wp.NINC;

    else

        NINC = 20;

    end

end

Nplies = numel(Geometry.Orient);

% ============================================================
% INITIALIZE INDEPENDENT DAMAGE STATE FOR EVERY PLY
% ============================================================

states = cell(1,Nplies);

for i = 1:Nplies

    states{i} = WeaveDamageInit(Wp);

end

% ============================================================
% COORDINATE TRANSFORMATIONS
% ============================================================

% Bednarcyk weave coordinates:
% x1 = through-thickness
% x2 = warp
% x3 = weft

% CLT material coordinates:
% x1 = warp
% x2 = weft
% x3 = through-thickness

pv_clt = [2 3 1 5 6 4];

pv_inv = [3 1 2 6 4 5];

% ============================================================
% INITIAL UNDAMAGED PLY PROPERTIES
% ============================================================

s0 = states{1};

Cund = WeaveUndamagedC(s0);

E0 = GetEffPropsFromC(Cund(pv_clt,pv_clt));

plyprops = cell(1,300);

% Assign a separate material card to each ply.
% Different plies can develop different damage.

for i = 1:Nplies

    m = Wp.Mat+i-1;

    Geometry.plymat(i) = m;

    plyprops{m}.used = true;

    plyprops{m}.name = ['woven ply ' num2str(i)];

    plyprops{m}.E1 = E0.E1;

    plyprops{m}.E2 = E0.E2;

    plyprops{m}.E3 = E0.E3;

    plyprops{m}.v12 = E0.v12;

    plyprops{m}.v13 = E0.v13;

    plyprops{m}.v23 = E0.v23;

    plyprops{m}.G12 = E0.G12;

    plyprops{m}.G13 = E0.G13;

    plyprops{m}.G23 = E0.G23;

    plyprops{m}.a1 = 0;

    plyprops{m}.a2 = 0;

    plyprops{m}.a3 = 0;

end

% Full 6x6 stiffness in Bednarcyk weave coordinates

Cply = cell(1,Nplies);

for i = 1:Nplies

    Cply{i} = Cund;

end

% ============================================================
% ALLOCATE HISTORY
% ============================================================

Hist.Nx = zeros(NINC,1);

Hist.ex = zeros(NINC,1);

Hist.ey = zeros(NINC,1);

Hist.sigply = zeros(NINC,2*Nplies);

Hist.ndamply = zeros(NINC,Nplies);

Hist.nsubply = zeros(NINC,Nplies);

Eply = zeros(NINC,Nplies);

Sbply = cell(1,Nplies);

damfig = 0;

% ============================================================
% LOADING INCREMENTS
% ============================================================

for INC = 1:NINC

    % --------------------------------------------------------
    % STRAIN-CONTROLLED LOADING
    % --------------------------------------------------------

    if Wp.StrainControl

        % Prescribed axial strain.
        % Remaining force and moment resultants are zero.

        LoadsI.Type = [1,2,2,2,2,2];

        LoadsI.Value = ...
            [Wp.epsxMax*INC/NINC,0,0,0,0,0];

    % --------------------------------------------------------
    % FORCE-CONTROLLED LOADING
    % --------------------------------------------------------

    else

        LoadsI.Type = [2,2,2,2,2,2];

        LoadsI.Value = ...
            [NxMax*INC/NINC,0,0,0,0,0];

    end

    LoadsI.DT = 0;

    LoadsI.NM = 2;

    LoadsI.EK = 1;

    % ========================================================
    % PRESERVE PREVIOUS CONVERGED DAMAGE HISTORY
    % ========================================================

    committed = states;

    % ========================================================
    % LAMINATE DAMAGE ITERATION
    % ========================================================

    for ITER = 1:Wp.NITER

        % Calculate laminate and ply strain distributions

        [Geometry,LamResults] = ...
            CLT(plyprops,Geometry,LoadsI);

        % All trials start from the previous
        % converged loading increment.

        trial = committed;

        err = 0;

        for i = 1:Nplies

            % In-plane strain components

            t3 = [1 2 6];

            % Out-of-plane strain components

            n3 = [3 4 5];

            % Average the top and bottom ply strains

            e3 = 0.5*( ...
                LamResults.MCstrain(:,2*i-1) + ...
                LamResults.MCstrain(:,2*i));

            eps_clt = zeros(6,1);

            eps_clt(t3) = e3(:);

            % Current full stiffness in CLT coordinates

            Cprev = Cply{i};

            Ccur = Cprev(pv_clt,pv_clt);

            % Calculate remaining strains from
            % the plane-stress condition

            eps_clt(n3) = ...
                -Ccur(n3,n3)\ ...
                (Ccur(n3,t3)*eps_clt(t3));

            % Transform into Bednarcyk weave coordinates

            epsply = eps_clt(pv_inv);

            % ================================================
            % MATRIX CRACK-BAND DAMAGE
            % ================================================

            [C,~,trial{i},Sbply{i},~,ndam_i,nsub_i] = ...
                WeavePlyDamage( ...
                committed{i},epsply,Wp.NITER,true);

            % Relative change in full ply stiffness

            err = max(err, ...
                norm(C-Cprev,'fro') / ...
                max(1,norm(C,'fro')));

            % Update full ply stiffness

            Cply{i} = C;

            % Obtain the engineering properties
            % required by the existing CLT solver

            E = GetEffPropsFromC(C(pv_clt,pv_clt));

            m = Wp.Mat+i-1;

            plyprops{m}.E1 = E.E1;

            plyprops{m}.E2 = E.E2;

            plyprops{m}.v12 = E.v12;

            plyprops{m}.G12 = E.G12;

            % Record damage counts

            Hist.ndamply(INC,i) = ndam_i;

            Hist.nsubply(INC,i) = nsub_i;

            Eply(INC,i) = E.E1;

        end

        % Check laminate stiffness convergence

        if err < Wp.MatrixCB.tolLam

            break;

        end

    end

    % ========================================================
    % CHECK CONVERGENCE
    % ========================================================

    if err >= Wp.MatrixCB.tolLam

        error('WeaveLamSimDamage:Nonconvergence', ...
            ['Laminate increment %d: ' ...
             'stiffness residual %.3e.'],INC,err);

    end

    % ========================================================
    % COMMIT CONVERGED DAMAGE STATE
    % ========================================================

    states = trial;

    % Final CLT calculation for the accepted stiffness

    [Geometry,LamResults] = ...
        CLT(plyprops,Geometry,LoadsI);

    for i = 1:Nplies

        Hist.sigply(INC,2*i-1) = ...
            LamResults.MCstress(1,2*i-1);

        Hist.sigply(INC,2*i) = ...
            LamResults.MCstress(1,2*i);

    end

    % ========================================================
    % RECORD LAMINATE RESPONSE
    % ========================================================

    if Wp.StrainControl

        % Reaction force resultant

        Hist.Nx(INC) = LamResults.NM(1);

    else

        Hist.Nx(INC) = NxMax*INC/NINC;

    end

    Hist.ex(INC) = LamResults.strain(1);

    Hist.ey(INC) = LamResults.strain(2);

    % ========================================================
    % COMMAND WINDOW OUTPUT
    % ========================================================

    fprintf(['  INC %3d/%3d  Nx = %10.3f  ' ...
        'ex = %11.6e  E1 = %10.1f\n'], ...
        INC,NINC,Hist.Nx(INC),Hist.ex(INC), ...
        plyprops{Wp.Mat}.E1);

    if Nplies >= 2

        fprintf('               ply E1: ply1 %.1f   ply2 %.1f\n', ...
            plyprops{Wp.Mat}.E1, ...
            plyprops{Wp.Mat+1}.E1);

    else

        fprintf('               ply E1: ply1 %.1f\n', ...
            plyprops{Wp.Mat}.E1);

    end

    fprintf(['               damaged blocks = %d   ' ...
        'damaged tow subcells = %d\n'], ...
        sum(Hist.ndamply(INC,:)), ...
        sum(Hist.nsubply(INC,:)));

    % ========================================================
    % LIVE FIGURES
    % ========================================================

    if Wp.Figures

        damfig = LamDamageWrite( ...
            damfig,Hist,Eply,INC,Nplies, ...
            states,Sbply,Geometry.Orient, ...
            sum(Geometry.tply));

    end

end

end

%=========================================================================%
% LOCAL FUNCTION: LAMINATE DAMAGE FIGURES
%=========================================================================%

function [damfig] = LamDamageWrite( ...
    damfig,Hist,Eply,INC,Nplies, ...
    states,Sbply,Orient,ttotal)

% Panel 1: Average stress-strain response
% Panel 2: Ply stiffness
% Panel 3: Damaged blocks and matrix subcells
% Panel 4: Von Mises stress distribution

if INC == 1

    damfig = figure('units','normalized', ...
        'outerposition',[0 0.5 1 0.5]);

else

    figure(damfig);

end

% ============================================================
% PANEL 1: LAMINATE STRESS-STRAIN
% ============================================================

subplot(2,2,1);

plot(Hist.ex(1:INC), ...
    Hist.Nx(1:INC)/ttotal, ...
    '-o','MarkerSize',3);

xlabel('\epsilon_x');

ylabel('\sigma_{avg}  [MPa]');

title('stress vs. strain');

grid on;

drawnow;

% ============================================================
% PANEL 2: PLY STIFFNESS
% ============================================================

subplot(2,2,2);

plot(1:INC,Eply(1:INC,:)/1000, ...
    '-o','MarkerSize',3);

xlabel('increment');

ylabel('ply E1  [GPa]');

title('ply stiffness vs. increment');

grid on;

drawnow;

% ============================================================
% PANEL 3: DAMAGE COUNTS
% ============================================================

subplot(2,2,3);

bar([Hist.ndamply(INC,:),Hist.nsubply(INC,:)]);

xlabel('ply');

ylabel('count');

legend('damaged blocks','damaged tow subcells', ...
    'Location','northwest');

title(['damage, INC = ',num2str(INC)]);

drawnow;

% ============================================================
% PANEL 4: VON MISES STRESS
% ============================================================

[vm,kp] = vm_top(states,Sbply);

if ~isempty(vm)

    ny = states{kp}.ny;

    nz = states{kp}.nz;

    [X,Y] = meshgrid(0:ny,0:nz);

    subplot(2,2,4);

    colormap(jet);

    pcolor(X,Y,pad2(vm.',nz,ny));

    shading interp;

    colorbar;

    axis image;

    xlabel('x_2 (warp, load)');

    ylabel('x_3 (weft)');

    title(['von Mises, ply ' num2str(kp) ...
        ' (' num2str(Orient(kp)) ...
        'deg), INC = ' num2str(INC)]);

    drawnow;

end

end

%=========================================================================%
% LOCAL FUNCTION: IDENTIFY PLY WITH MAXIMUM VON MISES STRESS
%=========================================================================%

function [vm,kp] = vm_top(states,Sbply)

best = -1;

kp = 1;

vm = [];

for p = 1:numel(states)

    if isempty(Sbply{p})

        continue;

    end

    v = vm_of(states{p},Sbply{p});

    if max(v(:)) > best

        best = max(v(:));

        vm = v;

        kp = p;

    end

end

end

%=========================================================================%
% LOCAL FUNCTION: CALCULATE VON MISES STRESS
%=========================================================================%

function [v] = vm_of(st,Sb)

nx = st.nx;

ny = st.ny;

nz = st.nz;

wruc = st.wruc;

v = zeros(ny,nz);

for b = 1:ny

    for g = 1:nz

        kk = nx;

        for k = nx:-1:1

            c = wruc.matsCh(k,b,g);

            if c == '5' || c == '6'

                kk = k;

                break;

            end

        end

        s = Sb{kk,b,g};

        v(b,g) = sqrt( ...
            (s(1)-s(2))^2 + ...
            (s(2)-s(3))^2 + ...
            (s(1)-s(3))^2 + ...
            6*s(4)^2 + ...
            6*s(5)^2 + ...
            6*s(6)^2)/sqrt(2);

    end

end

end

%=========================================================================%
% LOCAL FUNCTION: PAD MAP
%=========================================================================%

function [P] = pad2(M,ny,nx)

P = zeros(ny+1,nx+1);

P(1:ny,1:nx) = M;

P(ny+1,:) = P(ny,:);

P(:,nx+1) = P(:,nx);

end

%=========================================================================%
% LOCAL FUNCTION: UNDAMAGED WEAVE STIFFNESS
%=========================================================================%

function [C] = WeaveUndamagedC(state)

[~,~,~,~,C,~] = WeaveFields( ...
    state.Cb,state.ab, ...
    state.wruc.d,state.wruc.h,state.wruc.l, ...
    zeros(6,1));

end

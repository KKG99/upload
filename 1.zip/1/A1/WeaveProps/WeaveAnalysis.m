% +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% PRESS RUN ON THIS FILE. Weave properties: fibre+matrix -> tow -> weave.
% Settings are in WeaveProblemDef.m - edit that, not this.
% +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
clear; clc;
addpath('Functions/Utilities');
addpath('Functions/WriteResults');
addpath('Functions/Micromechanics');
addpath('Functions/Margins');
addpath('Functions/Damage');
addpath('WeaveProps');

[Wp] = WeaveProblemDef();

if (isfield(Wp, 'UseDirectTow') && logical(Wp.UseDirectTow)) || ...
        (~isfield(Wp, 'UseDirectTow') && isfield(Wp, 'TowProps') && ~isempty(Wp.TowProps))
    disp(['Weave Problem - RUC ' num2str(Wp.RUCid) ', direct tow properties']);
else
    disp(['Weave Problem - RUC ' num2str(Wp.RUCid) ', ' Wp.Theory ...
        ', tow RUC ' num2str(Wp.towRUCid) ', Vf = ' num2str(Wp.Vf)]);
end

[Weave, Tow] = RunWeave(Wp);

if isfield(Wp, 'Units') && ~isempty(Wp.Units)
    unitStr = [' ' char(Wp.Units)];
elseif max([Weave.E1 Weave.E2 Weave.E3]) < 1000
    unitStr = '';
else
    unitStr = ' MPa';
end

if max([Weave.E1 Weave.E2 Weave.E3]) < 1000
    fprintf('\nweave E1(thk) = %.4f   E2(warp) = %.4f   E3(weft) = %.4f   G23(in-plane) = %.4f%s\n', ...
        Weave.E1, Weave.E2, Weave.E3, Weave.G23, unitStr);
else
    fprintf('\nweave E1(thk) = %.1f   E2(warp) = %.1f   E3(weft) = %.1f   G23(in-plane) = %.1f%s\n', ...
        Weave.E1, Weave.E2, Weave.E3, Weave.G23, unitStr);
end

if isnan(Weave.Vf)
    fprintf('overall fibre Vf = N/A (direct tow Vf not specified)\n');
else
    fprintf('overall fibre Vf = %.6f\n', Weave.Vf);
end

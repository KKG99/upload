function Results = Verify_Tanov_TwoStep_DirectTow()
% VERIFY_TANOV_TWOSTEP_DIRECTTOW
% Compare the A1 RunWeave two-step woven model against Tables 7-10 of
% Bednarcyk & Arnold, AIAA Journal 41(9), 2003, pp. 1788-1796.
%
% Table 5: infiltrated tow and matrix properties (used as input directly).
% Table 6: RUC geometry and EXPLICIT inclination angle mu.
% Tables 7-10: published NASA GMC (2 step) weave engineering properties.
%
% Put this file in the A1 project root and run:
%     Results = Verify_Tanov_TwoStep_DirectTow;
%
% No RunMicro, constituent fibre RUC, calibration, or source edits.
% Existing WeaveHomog.m chooses GMCaniso or GMC3Daniso.
% All moduli are in GPa and all angles in degrees.

root = fileparts(mfilename('fullpath'));
addpath(fullfile(root,'WeaveProps'));
addpath(fullfile(root,'Functions','Micromechanics'));
addpath(fullfile(root,'Functions','Utilities'));

assert(exist('RunWeave','file')==2 && exist('GetRUC','file')==2, ...
    'Place this script in the A1 project root.');

fprintf('\n===============================================================\n');
fprintf('AIAA 2003 TABLES 5-10 | DIRECT TOW | TWO-STEP WEAVE\n');
fprintf('===============================================================\n');
fprintf('RunWeave:   %s\n',which('RunWeave'));
fprintf('WeaveHomog: %s\n',which('WeaveHomog'));

% Each row of the reference vector is:
% [E2 E3 E1 G12 G13 G23 nu21 nu31 nu23]
% (Table columns E2=E3, G12=G13 and nu21=nu31 are expanded here.)
% IMPORTANT: nu21/nu31 are NOT nu12/nu13.

cases(1).name = '35% E-glass/epoxy (Tables 5,6,7)';
cases(1).tow = struct('EA',47.77,'ET',18.02,'GA',3.877, ...
                      'vA',0.314,'vT',0.249,'Vf',0.65);
cases(1).mat = struct('E',3.5,'v',0.35);
cases(1).geom = struct('a',0.5385,'g',0.4615,'H',0.3077,'phi',9.46);
cases(1).reference = [18.1,18.1,9.85,2.54,2.54,2.76,0.318,0.318,0.177];
cases(1).nominalVf = 0.35;

cases(2).name = '35% SCS-6/TIMETAL 21S (Tables 5,6,8)';
cases(2).tow = struct('EA',293.88,'ET',253.84,'GA',93.46, ...
                      'vA',0.278,'vT',0.2846,'Vf',0.65);
cases(2).mat = struct('E',112.0,'v',0.34);
cases(2).geom = struct('a',0.5385,'g',0.4615,'H',0.3077,'phi',9.46);
cases(2).reference = [195.1,195.1,180.8,62.50,62.50,64.35,0.3073,0.3073,0.2813];
cases(2).nominalVf = 0.35;

cases(3).name = '46% Glass/epoxy (Tables 5,6,9)';
% Table 5 labels this tow as Glass/epoxy (a), Vf=80% (deduced).
cases(3).tow = struct('EA',58.61,'ET',14.49,'GA',5.38, ...
                      'vA',0.250,'vT',0.247,'Vf',0.80);
cases(3).mat = struct('E',3.45,'v',0.37);
cases(3).geom = struct('a',0.26,'g',0.74,'H',0.3701,'phi',4.2);
cases(3).reference = [11.84,11.84,6.21,1.68,1.68,1.78,0.402,0.402,0.167];
cases(3).nominalVf = 0.46;

cases(4).name = 'Graphite/epoxy (Table 6: 38%; Table 10: 35%)';
cases(4).tow = struct('EA',137.3,'ET',10.79,'GA',5.394, ...
                      'vA',0.26,'vT',0.46,'Vf',0.65);
cases(4).mat = struct('E',4.511,'v',0.38);
cases(4).geom = struct('a',0.58,'g',0.42,'H',0.1545,'phi',1.4);
cases(4).reference = [45.08,45.08,10.12,2.756,2.756,3.235,0.4637,0.4637,0.0564];
cases(4).nominalVf = 0.35; % title in Table 10; Table 6 says 38%

labels = {'E2','E3','E1','G12','G13','G23','nu21','nu31','nu23'};
Results = repmat(struct('name','','C',[],'computed',[], ...
    'reference',[],'percentError',[],'overallVf',NaN,'crimpDeg',NaN), ...
    numel(cases),1);

for k = 1:numel(cases)
    D = cases(k);

    Wp = struct();
    Wp.RUCid = 401;              % Existing plain-weave RUC
    Wp.Theory = 'GMC';           % Unused in direct-tow mode
    Wp.UseDirectTow = true;     % BYPASS RunMicro
    Wp.UseDirectMatrix = true;  % Use Table 5 matrix directly
    Wp.UseCustomGeom = true;    % Use Table 6 geometry directly
    Wp.TowProps = D.tow;
    Wp.MatrixProps = D.mat;
    Wp.Geom = D.geom;
    Wp.Figures = false;
    Wp.Units = 'GPa';
    Wp.epsw = [0;1;0;0;0;0];

    fprintf('\n===============================================================\n');
    fprintf('CASE %d: %s\n',k,D.name);
    fprintf('Tow: EA=%g ET=%g GA=%g vA=%g vT=%g Vf=%.3f\n', ...
        D.tow.EA,D.tow.ET,D.tow.GA,D.tow.vA,D.tow.vT,D.tow.Vf);
    fprintf('Matrix: E=%g nu=%g | a=%g g=%g H=%g mu=%g deg\n', ...
        D.mat.E,D.mat.v,D.geom.a,D.geom.g,D.geom.H,D.geom.phi);

    [W,T,~,~,~,~,RUC] = RunWeave(Wp);
    assert(T.direct,'Direct tow mode was not activated.');

    % Read engineering constants directly from the FULL compliance matrix.
    % Table 7-10 report nu21 and nu31; RunWeave's display uses nu12/nu13.
    S = W.Cstar\eye(6);
    calculated = [ ...
        1/S(2,2), 1/S(3,3), 1/S(1,1), ...
        1/S(6,6), 1/S(5,5), 1/S(4,4), ...
        -S(1,2)/S(2,2), -S(1,3)/S(3,3), -S(3,2)/S(2,2)];
    pct = 100*(calculated-D.reference)./abs(D.reference);

    fprintf('PROPERTY     Calculated        NASA 2-step     Error (%%)\n');
    fprintf('--------------------------------------------------------\n');
    for j = 1:numel(labels)
        fprintf('%-7s %14.6f  %14.6f   %+10.3f\n', ...
            labels{j},calculated(j),D.reference(j),pct(j));
    end
    fprintf('--------------------------------------------------------\n');
    fprintf('Maximum absolute relative error: %.3f%%\n',max(abs(pct)));
    fprintf('RUC tow volume fraction: %.6f\n',W.towVolFrac);
    fprintf('Calculated overall fibre Vf: %.4f (%.2f%%)\n',W.Vf,100*W.Vf);
    fprintf('Nominal Vf in result table: %.2f%%\n',100*D.nominalVf);
    fprintf('RUC maximum abs(crimp): %.6f deg\n',max(abs(RUC.crimp(:))));
    if abs(W.Vf-D.nominalVf)>0.01
        fprintf('WARNING: nominal and RUC-based fibre fractions differ.\n');
        fprintf('  This may be a geometry/label convention mismatch, NOT a solver error.\n');
    end
    if abs(max(abs(RUC.crimp(:)))-D.geom.phi)>1e-8
        warning('RUC inclination does not equal Table 6 mu.');
    end

    Results(k).name = D.name;
    Results(k).C = W.Cstar;
    Results(k).computed = calculated;
    Results(k).reference = D.reference;
    Results(k).percentError = pct;
    Results(k).overallVf = W.Vf;
    Results(k).crimpDeg = max(abs(RUC.crimp(:)));
end

fprintf('\n=============== FOUR-CASE SUMMARY ===============\n');
fprintf('%-7s %12s %12s %12s %12s %12s\n', ...
    'Case','E2 calc','E2 NASA','G23 calc','G23 NASA','Max err %');
for k = 1:numel(Results)
    r = Results(k);
    fprintf('%-7d %12.4f %12.4f %12.4f %12.4f %12.3f\n', ...
        k,r.computed(1),r.reference(1), ...
        r.computed(6),r.reference(6),max(abs(r.percentError)));
end
fprintf('=================================================\n');
fprintf('Only NASA GMC (2 step) rows are used as numerical references.\n');
fprintf('GMC (1 step) is a different algorithm and is not computed here.\n');
end
